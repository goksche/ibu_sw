// Layout Component - Sidebar + TopBar + Main Content
import { ReactNode, useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import Footer from '../Footer';
import { cn } from '@/lib/utils';

const SIDEBAR_STORAGE_KEY = 'sidebar-collapsed';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [collapsed, setCollapsed] = useState(() => {
    try {
      const stored = localStorage.getItem(SIDEBAR_STORAGE_KEY);
      return stored === 'true';
    } catch {
      return false;
    }
  });

  // Responsive: auto-collapse on small screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setCollapsed(true);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleCollapsed = () => {
    setCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(SIDEBAR_STORAGE_KEY, String(next));
      } catch {
        // localStorage not available
      }
      return next;
    });
  };

  return (
    /* Kein overflow-y im Layout: lange Listen (Teilnehmer) per normalem Fenster-Scroll — eine Scroll-Spalte, volle Liste sichtbar */
    <div className="layout-shell min-h-screen bg-background text-foreground flex flex-col">
      <Sidebar collapsed={collapsed} onToggle={toggleCollapsed} />
      <TopBar sidebarCollapsed={collapsed} />

      <div
        className={cn(
          'flex flex-1 flex-col transition-[margin-left] duration-300 ease-in-out',
          collapsed ? 'ml-[var(--sidebar-collapsed-width)]' : 'ml-[var(--sidebar-width)]'
        )}
      >
        <main className="layout-main w-full max-w-[1400px] mx-auto p-6">
          {children}
        </main>
        <Footer />
      </div>
    </div>
  );
}
