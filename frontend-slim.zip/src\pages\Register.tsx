import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, Input, Button } from '../components/ui';
import { Envelope, Key, UserPlus, CheckCircle } from 'phosphor-react';
import { registrationService } from '../services/registrationService';
import Footer from '../components/Footer';
import LanguageSwitcher from '../components/LanguageSwitcher';
import { formatAuthFlowError } from '../utils/authErrors';

type Step = 'form' | 'otp' | 'done';

export default function Register() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [step, setStep] = useState<Step>('form');
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let tick = 0;
    let scanY = 0;
    let frameId = 0;
    const CYAN = '0, 212, 255';
    const SCAN_SPEED = 0.4;
    const PARTICLE_COUNT = 55;
    let particles: Array<{ x: number; y: number; r: number; vy: number; alpha: number; fade: number }> = [];

    const makeParticle = (fromBottom = false) => ({
      x: Math.random() * width,
      y: fromBottom ? height + 4 : Math.random() * height,
      r: Math.random() * 1.2 + 0.3,
      vy: -(Math.random() * 0.35 + 0.1),
      alpha: Math.random() * 0.5 + 0.1,
      fade: Math.random() * 0.003 + 0.001,
    });

    const initParticles = () => {
      particles = Array.from({ length: PARTICLE_COUNT }, () => makeParticle(false));
    };

    const resize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initParticles();
    };

    const drawGrid = () => {
      const horizon = height * 0.52;
      const vpX = width / 2;
      const lines = 24;
      const spread = 3.6;

      ctx.save();
      ctx.lineWidth = 1;

      for (let i = 0; i <= lines; i++) {
        const t = i / lines;
        const yRaw = horizon + Math.pow(t, 1.6) * (height - horizon);
        const y = ((yRaw - horizon + tick * SCAN_SPEED) % (height - horizon)) + horizon;
        const xL = vpX - (width * spread / 2) * Math.pow(t, 1.0);
        const xR = vpX + (width * spread / 2) * Math.pow(t, 1.0);
        const alpha = Math.pow(t, 0.7) * 0.18;
        ctx.strokeStyle = `rgba(${CYAN}, ${alpha})`;
        ctx.beginPath();
        ctx.moveTo(xL, y);
        ctx.lineTo(xR, y);
        ctx.stroke();
      }

      const vLines = 16;
      for (let i = 0; i <= vLines; i++) {
        const t = i / vLines;
        const xB = vpX - width * spread / 2 + t * width * spread;
        ctx.strokeStyle = `rgba(${CYAN}, 0.06)`;
        ctx.beginPath();
        ctx.moveTo(vpX, horizon);
        ctx.lineTo(xB, height + 40);
        ctx.stroke();
      }

      ctx.restore();
    };

    const drawHorizon = () => {
      const y = height * 0.52;
      const gradient = ctx.createLinearGradient(0, y - 60, 0, y + 60);
      gradient.addColorStop(0, `rgba(${CYAN}, 0)`);
      gradient.addColorStop(0.5, `rgba(${CYAN}, 0.07)`);
      gradient.addColorStop(1, `rgba(${CYAN}, 0)`);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, y - 60, width, 120);
    };

    const drawParticles = () => {
      particles.forEach((p, i) => {
        p.y += p.vy;
        p.alpha -= p.fade;
        if (p.alpha <= 0 || p.y < -10) {
          particles[i] = makeParticle(true);
          return;
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${CYAN}, ${p.alpha})`;
        ctx.fill();
      });
    };

    const drawScanLine = () => {
      scanY = (scanY + 0.8) % height;
      const gradient = ctx.createLinearGradient(0, scanY - 60, 0, scanY + 2);
      gradient.addColorStop(0, `rgba(${CYAN}, 0)`);
      gradient.addColorStop(1, `rgba(${CYAN}, 0.04)`);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, scanY - 60, width, 62);
      ctx.strokeStyle = `rgba(${CYAN}, 0.12)`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, scanY);
      ctx.lineTo(width, scanY);
      ctx.stroke();
    };

    const loop = () => {
      tick += 1;
      ctx.clearRect(0, 0, width, height);

      const bg = ctx.createRadialGradient(width / 2, height * 0.5, 0, width / 2, height * 0.5, width * 0.8);
      bg.addColorStop(0, '#080c1a');
      bg.addColorStop(1, '#04050d');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      drawGrid();
      drawHorizon();
      drawParticles();
      drawScanLine();
      frameId = window.requestAnimationFrame(loop);
    };

    window.addEventListener('resize', resize);
    resize();
    frameId = window.requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('resize', resize);
      if (frameId) {
        window.cancelAnimationFrame(frameId);
      }
    };
  }, []);

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);

    try {
      const normalizedLastName = lastName.trim();
      const res = await registrationService.register({
        email,
        first_name: firstName.trim(),
        last_name: normalizedLastName || undefined,
      });

      if (res.dev_otp_code) {
        setInfo(`DEV-OTP: ${res.dev_otp_code}`);
        try {
          await registrationService.verifyOTP(email, res.dev_otp_code);
          setStep('done');
          return;
        } catch (err: any) {
          setError(err.response?.data?.detail || t('register.verificationFailed'));
          return;
        }
      } else {
        setInfo(t('register.codeSentInfo'));
      }
      setStep('otp');
    } catch (err: unknown) {
      setError(formatAuthFlowError(err, t, { fallbackKey: 'register.registrationFailed' }));
    } finally {
      setLoading(false);
    }
  };

  const handleOTPSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await registrationService.verifyOTP(email, otpCode);
      setStep('done');
    } catch (err: unknown) {
      setError(formatAuthFlowError(err, t, { fallbackKey: 'register.invalidCode' }));
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setStep('form');
    setOtpCode('');
    setError('');
    setInfo('');
  };

  const inputClassName = 'border-[rgba(0,212,255,0.15)] bg-[rgba(255,255,255,0.03)] text-[#e8eaf0] placeholder:text-[#6f7690] focus-visible:ring-[rgba(0,212,255,0.45)]';

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-[#04050d] text-[#e8eaf0]">
      <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 z-0" />
      <div className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(ellipse_at_center,rgba(0,212,255,0.08)_0%,rgba(4,5,13,0.92)_70%)]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(4,5,13,0.88)_100%)]" />

      <div className="absolute top-4 right-4 z-[1400] pointer-events-auto">
        <LanguageSwitcher />
      </div>

      <div className="relative z-[10] flex flex-1 items-center justify-center px-4 py-10">
        <Card className="w-full max-w-[440px] border-[rgba(0,212,255,0.18)] bg-[rgba(8,12,26,0.82)] text-[#e8eaf0] shadow-[0_24px_60px_rgba(0,0,0,0.55)] backdrop-blur-sm">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full border border-[rgba(0,212,255,0.2)] px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-[#00d4ff]">
              <span className="h-2 w-2 rounded-full bg-[#00d4ff]" />
              Account Registration
            </div>
            <CardTitle className="text-3xl font-semibold tracking-tight text-[#f4f8ff]">{t('login.appName')}</CardTitle>
            <CardDescription className="text-[#8f96ad]">{t('login.appDescription')}</CardDescription>
          </CardHeader>

          <CardContent>
            {step === 'form' && (
              <>
                <h2 className="mb-6 text-center text-xl font-semibold text-[#f4f8ff]">{t('register.title')}</h2>
                <form onSubmit={handleRegisterSubmit} className="space-y-4">
                  <Input
                    className={inputClassName}
                    label={t('register.firstName')}
                    type="text"
                    value={firstName}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFirstName(e.target.value)}
                    required
                  />
                  <Input
                    className={inputClassName}
                    label={t('register.lastName')}
                    type="text"
                    value={lastName}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLastName(e.target.value)}
                  />
                  <Input
                    className={inputClassName}
                    label={t('register.email')}
                    type="email"
                    value={email}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                    required
                  />

                  {info && (
                    <div className="rounded-lg border border-[rgba(0,212,255,0.35)] bg-[rgba(0,212,255,0.12)] p-3 text-sm text-[#7ae8ff]">
                      {info}
                    </div>
                  )}
                  {error && (
                    <div className="rounded-lg border border-red-400/40 bg-red-500/10 p-3 text-sm text-red-300">
                      {error}
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full gap-2 bg-[#00d4ff] font-semibold text-[#04050d] hover:bg-[#33dcff]"
                  >
                    {loading ? t('register.sending') : (
                      <>
                        <Envelope size={18} /> {t('register.sendCode')}
                      </>
                    )}
                  </Button>

                  <div className="text-center mt-4">
                    <button
                      type="button"
                      onClick={() => navigate('/login')}
                      className="cursor-pointer border-none bg-transparent text-sm text-[#7ae8ff] hover:underline"
                    >
                      {t('register.alreadyAccount')}
                    </button>
                  </div>
                </form>
              </>
            )}

            {step === 'otp' && (
              <>
                <h2 className="mb-6 text-center text-xl font-semibold text-[#f4f8ff]">{t('register.codeTitle')}</h2>
                <form onSubmit={handleOTPSubmit} className="space-y-4">
                  <p className="text-center text-sm text-[#8f96ad]" dangerouslySetInnerHTML={{ __html: t('register.codeSent', { email }) }} />
                  <Input
                    className={inputClassName}
                    label={t('register.confirmationCode')}
                    type="text"
                    value={otpCode}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOtpCode(e.target.value)}
                    required
                  />

                  {error && (
                    <div className="rounded-lg border border-red-400/40 bg-red-500/10 p-3 text-sm text-red-300">
                      {error}
                    </div>
                  )}

                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={handleBack}
                      className="flex-1 border border-[rgba(0,212,255,0.18)] bg-[rgba(255,255,255,0.04)] text-[#c6d0ec] hover:bg-[rgba(255,255,255,0.08)]"
                    >
                      {t('common.back')}
                    </Button>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="flex-1 gap-2 bg-[#00d4ff] font-semibold text-[#04050d] hover:bg-[#33dcff]"
                    >
                      {loading ? t('register.verifying') : (
                        <>
                          <Key size={18} /> {t('register.confirm')}
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </>
            )}

            {step === 'done' && (
              <div className="space-y-4 py-4 text-center">
                <CheckCircle size={48} weight="fill" className="mx-auto text-emerald-300" />
                <h2 className="text-xl font-semibold text-[#f4f8ff]">{t('register.emailVerified')}</h2>
                <p className="text-[#8f96ad]">
                  {t('register.submittedMessage')}
                </p>
                <p className="text-sm text-[#8f96ad]">
                  {t('register.notificationMessage')}
                </p>
                <Button
                  variant="secondary"
                  onClick={() => navigate('/login')}
                  className="mt-4 gap-2 border border-[rgba(0,212,255,0.18)] bg-[rgba(255,255,255,0.04)] text-[#c6d0ec] hover:bg-[rgba(255,255,255,0.08)]"
                >
                  <UserPlus size={18} /> {t('register.goToLogin')}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}
