// Login Page
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';
import { useAuth } from '../contexts/AuthContext';
import { Card, Input, Button } from '../components/ui';
import { theme } from '../theme/theme';

export default function Login() {
  const navigate = useNavigate();
  const { refreshUser } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await authService.login({ username, password });
      await refreshUser();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Login fehlgeschlagen');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: theme.colors.background.primary,
      }}
    >
      <Card style={{ width: '400px' }}>
        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <h1
            style={{
              margin: 0,
              color: theme.colors.text.primary,
              fontSize: '1.5rem',
              fontWeight: 'bold',
              letterSpacing: '2px',
              fontFamily: 'Arial, sans-serif',
            }}
          >
            IBU Turniere
          </h1>
          <p
            style={{
              margin: '0.25rem 0 0',
              color: theme.colors.text.secondary,
              fontSize: '0.75rem',
              letterSpacing: '1px',
            }}
          >
            Turnier-Verwaltung
          </p>
        </div>

        <h2 style={{ marginBottom: '1.5rem', textAlign: 'center', color: theme.colors.text.secondary }}>
          Login
        </h2>

        <form onSubmit={handleSubmit}>
          <Input
            label="Benutzername"
            type="text"
            value={username}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUsername(e.target.value)}
            required
          />

          <Input
            label="Passwort"
            type="password"
            value={password}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
            required
          />

          {error && (
            <div
              style={{
                color: theme.colors.accent.error,
                marginBottom: '1rem',
                padding: '0.75rem',
                background: `${theme.colors.accent.error}20`,
                border: `1px solid ${theme.colors.accent.error}`,
                borderRadius: theme.borderRadius.card,
              }}
            >
              {error}
            </div>
          )}

          <Button type="submit" variant="primary" disabled={loading} fullWidth>
            {loading ? 'Wird angemeldet...' : 'Anmelden'}
          </Button>
        </form>
      </Card>
    </div>
  );
}