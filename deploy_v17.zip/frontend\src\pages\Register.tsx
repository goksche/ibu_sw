import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, Input, Button } from '../components/ui';
import { Envelope, Key, UserPlus, CheckCircle } from 'phosphor-react';
import { registrationService } from '../services/registrationService';
import Footer from '../components/Footer';

type Step = 'form' | 'otp' | 'done';

export default function Register() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('form');
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);

    try {
      const res = await registrationService.register({ email, first_name: firstName, last_name: lastName });

      if (res.dev_otp_code) {
        setInfo(`DEV-OTP: ${res.dev_otp_code}`);
        try {
          await registrationService.verifyOTP(email, res.dev_otp_code);
          setStep('done');
          return;
        } catch (err: any) {
          setError(err.response?.data?.detail || 'Verifizierung fehlgeschlagen');
          return;
        }
      } else {
        setInfo('Bestätigungscode wurde per E-Mail versendet.');
      }
      setStep('otp');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Registrierung fehlgeschlagen');
    } finally {
      setLoading(false);
    }
  };

  const handleOTPSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await registrationService.verifyOTP(email, otpCode);
      setStep('done');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Ungültiger oder abgelaufener Code');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setStep('form');
    setOtpCode('');
    setError('');
    setInfo('');
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <div className="flex justify-center items-center flex-1">
        <Card className="w-[440px]">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">FinalStage.ch</CardTitle>
            <CardDescription>Turnier-Verwaltung</CardDescription>
          </CardHeader>

          <CardContent>
            {step === 'form' && (
              <>
                <h2 className="text-xl font-semibold text-center text-foreground mb-6">Registrieren</h2>
                <form onSubmit={handleRegisterSubmit} className="space-y-4">
                  <Input
                    label="Vorname"
                    type="text"
                    value={firstName}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFirstName(e.target.value)}
                    required
                  />
                  <Input
                    label="Nachname"
                    type="text"
                    value={lastName}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLastName(e.target.value)}
                    required
                  />
                  <Input
                    label="E-Mail"
                    type="email"
                    value={email}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                    required
                  />

                  {info && (
                    <div className="p-3 rounded-lg border border-primary bg-primary/10 text-primary text-sm">
                      {info}
                    </div>
                  )}
                  {error && (
                    <div className="p-3 rounded-lg border border-destructive bg-destructive/10 text-destructive text-sm">
                      {error}
                    </div>
                  )}

                  <Button type="submit" disabled={loading} className="w-full gap-2">
                    {loading ? 'Wird gesendet...' : (
                      <>
                        <Envelope size={18} /> Code anfordern
                      </>
                    )}
                  </Button>

                  <div className="text-center mt-4">
                    <button
                      type="button"
                      onClick={() => navigate('/login')}
                      className="text-sm text-primary hover:underline bg-transparent border-none cursor-pointer"
                    >
                      Bereits ein Konto? Anmelden
                    </button>
                  </div>
                </form>
              </>
            )}

            {step === 'otp' && (
              <>
                <h2 className="text-xl font-semibold text-center text-foreground mb-6">Code eingeben</h2>
                <form onSubmit={handleOTPSubmit} className="space-y-4">
                  <p className="text-sm text-muted-foreground text-center">
                    Ein Bestätigungscode wurde an <b>{email}</b> gesendet.
                  </p>
                  <Input
                    label="Bestätigungscode"
                    type="text"
                    value={otpCode}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOtpCode(e.target.value)}
                    required
                  />

                  {error && (
                    <div className="p-3 rounded-lg border border-destructive bg-destructive/10 text-destructive text-sm">
                      {error}
                    </div>
                  )}

                  <div className="flex gap-3">
                    <Button type="button" variant="secondary" onClick={handleBack} className="flex-1">
                      Zurück
                    </Button>
                    <Button type="submit" disabled={loading} className="flex-1 gap-2">
                      {loading ? 'Wird geprüft...' : (
                        <>
                          <Key size={18} /> Bestätigen
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </>
            )}

            {step === 'done' && (
              <div className="text-center space-y-4 py-4">
                <CheckCircle size={48} weight="fill" className="text-green-500 mx-auto" />
                <h2 className="text-xl font-semibold text-foreground">E-Mail verifiziert!</h2>
                <p className="text-muted-foreground">
                  Dein Registrierungsantrag wurde eingereicht und wartet auf Freigabe durch den Administrator.
                </p>
                <p className="text-sm text-muted-foreground">
                  Du wirst per E-Mail benachrichtigt, sobald dein Konto freigeschaltet wurde.
                </p>
                <Button variant="secondary" onClick={() => navigate('/login')} className="mt-4 gap-2">
                  <UserPlus size={18} /> Zur Anmeldung
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}
