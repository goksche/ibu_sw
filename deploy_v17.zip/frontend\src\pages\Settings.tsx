import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { settingsService, DEFAULT_APP_SETTINGS, DEFAULT_USER_SETTINGS, UserSettings as UserSettingsType } from '../services/settingsService';
import { AppSettings, LiveTickerSlideType } from '../types';
import { ArrowLeft, Sliders, User, Globe } from 'phosphor-react';
import { applyLayoutPreset } from '../utils/layout';
import { applyFontFamily, FONT_FAMILY_MAP } from '../utils/typography';

const SLIDE_LABELS: Record<LiveTickerSlideType, string> = {
  groups: 'Gruppen',
  qualification: 'Qualifikation',
  ko: 'KO-Phase',
};

export default function Settings() {
  const navigate = useNavigate();
  const { isAdmin, isPowerAdmin } = useAuth();

  // User-individual settings
  const [userSettings, setUserSettings] = useState<UserSettingsType>(DEFAULT_USER_SETTINGS);
  const [userLoading, setUserLoading] = useState(true);
  const [userSaving, setUserSaving] = useState(false);
  const [userError, setUserError] = useState<string | null>(null);
  const [userSuccess, setUserSuccess] = useState<string | null>(null);

  // Global settings (admin only)
  const [globalSettings, setGlobalSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const [globalLoading, setGlobalLoading] = useState(true);
  const [globalSaving, setGlobalSaving] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);
  const [globalSuccess, setGlobalSuccess] = useState<string | null>(null);

  useEffect(() => {
    const loadUserSettings = async () => {
      try {
        const data = await settingsService.getUserSettings();
        setUserSettings(data);
      } catch {
        setUserError('Einstellungen konnten nicht geladen werden.');
      } finally {
        setUserLoading(false);
      }
    };
    loadUserSettings();
  }, []);

  useEffect(() => {
    if (!isPowerAdmin) {
      setGlobalLoading(false);
      return;
    }
    const loadGlobal = async () => {
      try {
        const data = await settingsService.getGlobalSettings();
        setGlobalSettings(data);
      } catch {
        setGlobalError('Globale Einstellungen konnten nicht geladen werden.');
      } finally {
        setGlobalLoading(false);
      }
    };
    loadGlobal();
  }, [isPowerAdmin]);

  const handleUserSave = async () => {
    setUserSaving(true);
    setUserError(null);
    setUserSuccess(null);
    try {
      const saved = await settingsService.updateUserSettings(userSettings);
      setUserSettings(saved);
      applyLayoutPreset(saved.layout as any);
      applyFontFamily(saved.font_family as any);
      setUserSuccess('Einstellungen gespeichert.');
    } catch {
      setUserError('Speichern fehlgeschlagen.');
    } finally {
      setUserSaving(false);
    }
  };

  // --- Global settings handlers (admin only) ---

  const updateLiveTicker = (patch: Partial<AppSettings['live_ticker']>) => {
    setGlobalSettings(prev => ({
      ...prev,
      live_ticker: { ...prev.live_ticker, ...patch },
    }));
  };

  const updateGlobalDashboard = (patch: Partial<AppSettings['dashboard']>) => {
    setGlobalSettings(prev => ({
      ...prev,
      dashboard: { ...prev.dashboard, ...patch },
    }));
  };

  const updateGlobalPlaceholders = (patch: Partial<AppSettings['placeholders']>) => {
    setGlobalSettings(prev => ({
      ...prev,
      placeholders: { ...prev.placeholders, ...patch },
    }));
  };

  const clampNumber = (value: string, min: number, max: number) => {
    const num = Number(value);
    if (Number.isNaN(num)) return null;
    return Math.min(max, Math.max(min, num));
  };

  const moveSlide = (index: number, direction: -1 | 1) => {
    const order = [...globalSettings.live_ticker.slide_order];
    const target = index + direction;
    if (target < 0 || target >= order.length) return;
    [order[index], order[target]] = [order[target], order[index]];
    updateLiveTicker({ slide_order: order });
  };

  const handleGlobalSave = async () => {
    setGlobalSaving(true);
    setGlobalError(null);
    setGlobalSuccess(null);
    try {
      const saved = await settingsService.updateGlobalSettings(globalSettings);
      setGlobalSettings(saved);
      setGlobalSuccess('Globale Einstellungen gespeichert.');
    } catch {
      setGlobalError('Speichern fehlgeschlagen.');
    } finally {
      setGlobalSaving(false);
    }
  };

  if (userLoading || globalLoading) {
    return <div className="p-8 text-foreground">Lädt...</div>;
  }

  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-3">
          <Sliders size={26} className="text-foreground" />
          <h1 className="m-0 text-foreground">Einstellungen</h1>
        </div>
        <Button variant="secondary" onClick={() => navigate('/dashboard')}>
          <ArrowLeft size={18} className="mr-2 align-middle" />
          Zurück
        </Button>
      </div>

      {/* ===== USER SETTINGS (all roles) ===== */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <User size={20} className="text-primary" />
          <h2 className="m-0 text-foreground text-lg">Meine Einstellungen</h2>
        </div>

        {userError && <div className="mb-4 text-destructive text-sm">{userError}</div>}
        {userSuccess && <div className="mb-4 text-green-500 text-sm">{userSuccess}</div>}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="mt-0">Darstellung</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                label="Layout"
                value={userSettings.layout}
                onChange={(e) => {
                  const v = e.target.value;
                  setUserSettings(prev => ({ ...prev, layout: v }));
                  applyLayoutPreset(v as any);
                }}
                options={[
                  { value: 'standard', label: 'Standard' },
                  { value: 'neon', label: 'NeonGreen' },
                  { value: 'neon_yellow', label: 'NeonYellow' },
                  { value: 'neon_cyan', label: 'NeonCyan' },
                  { value: 'neon_blue', label: 'NeonBlue' },
                ]}
              />
              <Select
                label="Schriftart"
                value={userSettings.font_family}
                onChange={(e) => {
                  const v = e.target.value;
                  setUserSettings(prev => ({ ...prev, font_family: v }));
                  applyFontFamily(v as any);
                }}
                options={Object.keys(FONT_FAMILY_MAP).map((font) => ({
                  value: font,
                  label: font,
                }))}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="mt-0">Dashboard & Allgemein</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                label="Standard-Sortierung"
                value={userSettings.dashboard_sort}
                onChange={(e) => setUserSettings(prev => ({ ...prev, dashboard_sort: e.target.value as any }))}
                options={[
                  { value: 'date', label: 'Datum' },
                  { value: 'name', label: 'Name' },
                  { value: 'status', label: 'Status' },
                ]}
              />
              <Input
                label="Sprache"
                value={userSettings.language}
                onChange={(e) => setUserSettings(prev => ({ ...prev, language: e.target.value }))}
                disabled
              />
              <Input
                label="Zeitzone"
                value={userSettings.timezone}
                onChange={(e) => setUserSettings(prev => ({ ...prev, timezone: e.target.value }))}
                disabled
              />
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end mt-4">
          <Button variant="primary" onClick={handleUserSave} disabled={userSaving}>
            {userSaving ? 'Speichere...' : 'Meine Einstellungen speichern'}
          </Button>
        </div>
      </div>

      {/* ===== GLOBAL SETTINGS (admin only) ===== */}
      {isPowerAdmin && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Globe size={20} className="text-primary" />
            <h2 className="m-0 text-foreground text-lg">Globale Defaults (Admin)</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Diese Einstellungen gelten als Standard für neue Benutzer und den Live-Ticker.
          </p>

          {globalError && <div className="mb-4 text-destructive text-sm">{globalError}</div>}
          {globalSuccess && <div className="mb-4 text-green-500 text-sm">{globalSuccess}</div>}

          <div className="grid grid-cols-[2fr_1fr] gap-6">
            <div className="flex flex-col gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="mt-0">Live-Ticker</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="Umschaltzeit (Sek.)"
                      type="number"
                      min={5}
                      max={60}
                      value={globalSettings.live_ticker.slide_duration_sec}
                      onChange={(e) => {
                        const val = clampNumber(e.target.value, 5, 60);
                        if (val !== null) updateLiveTicker({ slide_duration_sec: val });
                      }}
                    />
                    <Input
                      label="Refresh-Intervall (Sek.)"
                      type="number"
                      min={10}
                      max={120}
                      value={globalSettings.live_ticker.refresh_interval_sec}
                      onChange={(e) => {
                        const val = clampNumber(e.target.value, 10, 120);
                        if (val !== null) updateLiveTicker({ refresh_interval_sec: val });
                      }}
                    />
                  </div>

                  <div className="mb-4">
                    <div className="font-semibold mb-2 text-foreground">Folien-Reihenfolge</div>
                    {globalSettings.live_ticker.slide_order.map((slide, idx) => (
                      <div key={`${slide}-${idx}`} className="flex items-center gap-2 mb-2">
                        <div className="flex-1 text-foreground">{SLIDE_LABELS[slide]}</div>
                        <Button variant="secondary" onClick={() => moveSlide(idx, -1)} disabled={idx === 0}>Hoch</Button>
                        <Button variant="secondary" onClick={() => moveSlide(idx, 1)} disabled={idx === globalSettings.live_ticker.slide_order.length - 1}>Runter</Button>
                      </div>
                    ))}
                  </div>

                  <div className="mb-4">
                    <div className="font-semibold mb-2 text-foreground">Folien-Filter</div>
                    {(['groups', 'qualification', 'ko'] as LiveTickerSlideType[]).map((key) => (
                      <label key={key} className="flex items-center gap-2 mb-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={globalSettings.live_ticker.slides_enabled[key]}
                          onChange={(e) => updateLiveTicker({
                            slides_enabled: { ...globalSettings.live_ticker.slides_enabled, [key]: e.target.checked },
                          })}
                        />
                        <span className="text-foreground">{SLIDE_LABELS[key]}</span>
                      </label>
                    ))}
                  </div>

                  <div className="mb-4">
                    <div className="font-semibold mb-2 text-foreground">Anzeige-Details</div>
                    {[
                      { key: 'only_running_group_matches', label: 'Nur laufende Gruppenspiele' },
                      { key: 'show_spielfeld', label: 'Spielfeld anzeigen' },
                      { key: 'show_results', label: 'Ergebnis anzeigen' },
                      { key: 'mark_decision_matches', label: 'Entscheidungsspiele markieren' },
                    ].map(({ key, label }) => (
                      <label key={key} className="flex items-center gap-2 mb-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={(globalSettings.live_ticker as any)[key]}
                          onChange={(e) => updateLiveTicker({ [key]: e.target.checked })}
                        />
                        <span className="text-foreground">{label}</span>
                      </label>
                    ))}
                  </div>

                  <Select
                    label="Max Gruppen pro Folie"
                    value={globalSettings.live_ticker.max_groups_per_slide}
                    onChange={(e) => updateLiveTicker({ max_groups_per_slide: Number(e.target.value) as 1 | 2 })}
                    options={[
                      { value: 1, label: '1 Gruppe pro Folie' },
                      { value: 2, label: '2 Gruppen pro Folie' },
                    ]}
                  />
                </CardContent>
              </Card>
            </div>

            <div className="flex flex-col gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="mt-0">Standard-Darstellung</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select
                    label="Standard-Layout"
                    value={globalSettings.placeholders.layout}
                    onChange={(e) => updateGlobalPlaceholders({ layout: e.target.value as any })}
                    options={[
                      { value: 'standard', label: 'Standard' },
                      { value: 'neon', label: 'NeonGreen' },
                      { value: 'neon_yellow', label: 'NeonYellow' },
                      { value: 'neon_cyan', label: 'NeonCyan' },
                      { value: 'neon_blue', label: 'NeonBlue' },
                    ]}
                  />
                  <Select
                    label="Standard-Schriftart"
                    value={globalSettings.placeholders.font_family}
                    onChange={(e) => updateGlobalPlaceholders({ font_family: e.target.value as any })}
                    options={Object.keys(FONT_FAMILY_MAP).map((font) => ({ value: font, label: font }))}
                  />
                  <Select
                    label="Standard-Sortierung"
                    value={globalSettings.dashboard.default_sort}
                    onChange={(e) => updateGlobalDashboard({ default_sort: e.target.value as any })}
                    options={[
                      { value: 'date', label: 'Datum' },
                      { value: 'name', label: 'Name' },
                      { value: 'status', label: 'Status' },
                    ]}
                  />
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="flex justify-end mt-4">
            <Button variant="primary" onClick={handleGlobalSave} disabled={globalSaving}>
              {globalSaving ? 'Speichere...' : 'Globale Defaults speichern'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
