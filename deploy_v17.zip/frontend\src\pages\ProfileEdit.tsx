import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { profileService, UserProfile } from '../services/profileService';
import { ArrowLeft, UserCircle, Camera, Trash, Link as LinkIcon, LinkBreak } from 'phosphor-react';

export default function ProfileEdit() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [club, setClub] = useState('');
  const [bio, setBio] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [linkedParticipant, setLinkedParticipant] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const p = await profileService.getMyProfile();
        setProfile(p);
        setDisplayName(p.display_name || '');
        setClub(p.club || '');
        setBio(p.bio || '');
        setIsPrivate(p.is_private);
      } catch {
        setError('Profil konnte nicht geladen werden.');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      const updated = await profileService.updateMyProfile({
        display_name: displayName || undefined,
        club: club || undefined,
        bio: bio || undefined,
        is_private: isPrivate,
      });
      setProfile(updated);
      setSuccess('Profil gespeichert.');
    } catch {
      setError('Speichern fehlgeschlagen.');
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setError('Datei zu gross (max. 2 MB).');
      return;
    }
    setUploading(true);
    setError('');
    try {
      const updated = await profileService.uploadAvatar(file);
      setProfile(updated);
      setSuccess('Profilbild hochgeladen.');
    } catch {
      setError('Upload fehlgeschlagen.');
    } finally {
      setUploading(false);
    }
  };

  const handleAvatarDelete = async () => {
    if (!confirm('Profilbild wirklich löschen?')) return;
    try {
      const updated = await profileService.deleteAvatar();
      setProfile(updated);
      setSuccess('Profilbild gelöscht.');
    } catch {
      setError('Löschen fehlgeschlagen.');
    }
  };

  const handleUnlink = async () => {
    if (!confirm('Verknüpfung mit Teilnehmer aufheben?')) return;
    try {
      await profileService.unlinkParticipant();
      setLinkedParticipant(null);
      setSuccess('Verknüpfung aufgehoben.');
    } catch {
      setError('Aufheben fehlgeschlagen.');
    }
  };

  if (loading) return <div className="p-8 text-foreground">Lädt...</div>;

  const avatarSrc = profile?.avatar_url || null;

  return (
    <div className="p-8 max-w-[700px] mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-3">
          <UserCircle size={26} className="text-foreground" />
          <h1 className="m-0 text-foreground">Mein Profil</h1>
        </div>
        <Button variant="secondary" onClick={() => navigate('/dashboard')}>
          <ArrowLeft size={18} className="mr-2" /> Zurück
        </Button>
      </div>

      {error && <div className="mb-4 p-3 rounded-lg border border-destructive bg-destructive/10 text-destructive text-sm">{error}</div>}
      {success && <div className="mb-4 p-3 rounded-lg border border-green-500 bg-green-500/10 text-green-500 text-sm">{success}</div>}

      {/* Avatar */}
      <Card className="mb-6">
        <CardHeader><CardTitle className="mt-0">Profilbild</CardTitle></CardHeader>
        <CardContent>
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center overflow-hidden shrink-0">
              {avatarSrc ? (
                <img src={avatarSrc} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <UserCircle size={64} className="text-muted-foreground" />
              )}
            </div>
            <div className="flex flex-col gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handleAvatarUpload}
              />
              <Button
                variant="secondary"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="gap-2"
              >
                <Camera size={16} /> {uploading ? 'Lädt...' : 'Bild hochladen'}
              </Button>
              {avatarSrc && (
                <Button variant="danger" onClick={handleAvatarDelete} className="gap-2">
                  <Trash size={16} /> Bild entfernen
                </Button>
              )}
              <p className="text-xs text-muted-foreground">JPG, PNG oder WebP, max. 2 MB</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Fields */}
      <Card className="mb-6">
        <CardHeader><CardTitle className="mt-0">Profil-Daten</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">E-Mail</label>
            <p className="text-sm text-muted-foreground bg-muted rounded-md px-3 py-2">{user?.email || '–'}</p>
          </div>
          <Input
            label="Anzeigename"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder={user?.username || ''}
          />
          <Input
            label="Verein"
            value={club}
            onChange={(e) => setClub(e.target.value)}
          />
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Bio</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={1000}
              rows={3}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring resize-none"
              placeholder="Erzähl etwas über dich..."
            />
            <p className="text-xs text-muted-foreground mt-1">{bio.length}/1000</p>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={isPrivate}
              onChange={(e) => setIsPrivate(e.target.checked)}
            />
            <span className="text-sm text-foreground">Profil privat (nicht sichtbar für andere)</span>
          </label>
        </CardContent>
      </Card>

      <div className="flex justify-end mb-6">
        <Button variant="primary" onClick={handleSave} disabled={saving}>
          {saving ? 'Speichere...' : 'Profil speichern'}
        </Button>
      </div>

      {/* Participant Link Info */}
      {linkedParticipant && (
        <Card>
          <CardHeader><CardTitle className="mt-0">Teilnehmer-Verknüpfung</CardTitle></CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <LinkIcon size={18} className="text-primary" />
                <span className="text-foreground">Verknüpft mit: <b>{linkedParticipant}</b></span>
              </div>
              <Button variant="secondary" onClick={handleUnlink} className="gap-2">
                <LinkBreak size={16} /> Aufheben
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
