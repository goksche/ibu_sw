import { TournamentModeVariant } from './tournamentModeMatrix';

export interface ModeFlowPhase {
  title: string;
  steps: string[];
}

export interface ModeVariantInsight {
  id: TournamentModeVariant;
  title: string;
  intro: string;
  bullets: string[];
  flow: ModeFlowPhase[];
}

const MODE_VARIANT_INSIGHTS: Record<TournamentModeVariant, ModeVariantInsight> = {
  L1: {
    id: 'L1',
    title: 'L1 Round Robin',
    intro: 'Alle Teilnehmer spielen einmal gegeneinander. Die Rangliste ergibt sich direkt aus den Ligaspielen.',
    bullets: [
      'Jede Begegnung findet genau einmal statt.',
      'Konstante Anzahl Spiele pro Teilnehmer.',
      'Tie-Break Regeln entscheiden Gleichstaende.',
      'Ideal fuer kleine bis mittlere Felder.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['1 Liga-Block', 'Jeder gegen jeden (1x)'] },
      { title: 'Zwischenrunde', steps: ['Rangliste wird berechnet', 'Tie-Break bei Punktgleichheit'] },
      { title: 'Endrunde', steps: ['Finale Tabelle', 'Optionales Platzierungsspiel'] },
    ],
  },
  L2: {
    id: 'L2',
    title: 'L2 Double Round Robin',
    intro: 'Alle Teilnehmer spielen Hin- und Rueckrunde gegeneinander. Damit entsteht eine stabilere Rangliste als bei L1.',
    bullets: [
      'Jede Paarung wird zweimal gespielt.',
      'Mehr Datenpunkte fuer faire Platzierungen.',
      'Hoeherer Zeitbedarf als L1.',
      'Geeignet fuer leistungsorientierte Ligen.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Hinrunde: jeder gegen jeden'] },
      { title: 'Zwischenrunde', steps: ['Rueckrunde: gleiche Paarungen erneut'] },
      { title: 'Endrunde', steps: ['Gesamttabelle aus Hin+Rueckrunde'] },
    ],
  },
  L3: {
    id: 'L3',
    title: 'L3 Mehrere Gruppen',
    intro: 'Teilnehmer werden auf Gruppen verteilt. Innerhalb jeder Gruppe wird Round Robin gespielt.',
    bullets: [
      'Skaliert fuer groessere Teilnehmerfelder.',
      'Gruppen koennen zufaellig oder gesetzt verteilt werden.',
      'Ranglisten entstehen pro Gruppe.',
      'Optional mit nachgelagerter Qualifikation kombinierbar.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Mehrere Gruppen', 'Round Robin pro Gruppe'] },
      { title: 'Zwischenrunde', steps: ['Gruppentabellen', 'Tie-Break innerhalb Gruppe'] },
      { title: 'Endrunde', steps: ['Abschluss je Gruppe', 'Optional Gesamtwertung'] },
    ],
  },
  L4: {
    id: 'L4',
    title: 'L4 Swiss System',
    intro: 'Paarungen werden pro Runde nach aktueller Punktzahl erstellt. Es gibt keine festen Gruppen und kein klassisches KO.',
    bullets: [
      'Rundenweise Neu-Paarung nach Stand.',
      'Aehnlich starke Teilnehmer spielen gegeneinander.',
      'Effizient bei grossen Feldern.',
      'Rangliste basiert auf Punkten + Tie-Break.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Startpaarungen (Seed/Random)'] },
      { title: 'Zwischenrunde', steps: ['Runde 2..n nach Swiss-Regeln', 'Stand wird laufend aktualisiert'] },
      { title: 'Endrunde', steps: ['Finale Swiss-Tabelle', 'Platzierung nach Tie-Break'] },
    ],
  },
  K1: {
    id: 'K1',
    title: 'K1 Single Elimination',
    intro: 'Direkter KO-Baum. Eine Niederlage bedeutet Ausscheiden.',
    bullets: [
      'Sehr schneller Turnierablauf.',
      'Ein klarer Siegerpfad bis ins Finale.',
      'Optional mit Spiel um Platz 3.',
      'Geeignet bei knappen Zeitfenstern.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Seeding / Auslosung', 'KO-Start (z. B. Achtelfinale)'] },
      { title: 'Zwischenrunde', steps: ['Viertel- und Halbfinale'] },
      { title: 'Endrunde', steps: ['Finale', 'Optional Platz 3'] },
    ],
  },
  K2: {
    id: 'K2',
    title: 'K2 Double Elimination',
    intro: 'Teilnehmer scheiden erst nach zwei Niederlagen aus. Es gibt Winner- und Loser-Bracket.',
    bullets: [
      'Mehr Chancengleichheit als K1.',
      'Eine fruehe Niederlage ist korrigierbar.',
      'Komplexerer Spielplan mit mehr Matches.',
      'Finale kann Reset-Logik enthalten.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Winner Bracket Start'] },
      { title: 'Zwischenrunde', steps: ['Loser Bracket + Winner Bracket', 'Zwei Niederlagen = Aus'] },
      { title: 'Endrunde', steps: ['Grand Final', 'Optional Bracket-Reset'] },
    ],
  },
  K3: {
    id: 'K3',
    title: 'K3 Triple Elimination',
    intro: 'Ausscheiden erst nach drei Niederlagen. Sehr robustes KO-Format fuer grosse und ausgeglichene Felder.',
    bullets: [
      'Hohe Fehlertoleranz pro Teilnehmer.',
      'Deutlich laenger als Single/Double KO.',
      'Braucht klare Spielplansteuerung.',
      'Sinnvoll fuer Premium-Events.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Start im Hauptbaum'] },
      { title: 'Zwischenrunde', steps: ['Mehrere Auffangpfade', 'Drei Niederlagen = Aus'] },
      { title: 'Endrunde', steps: ['Finalphase der verbleibenden Top-Teilnehmer'] },
    ],
  },
  K4: {
    id: 'K4',
    title: 'K4 Page Playoff',
    intro: 'Top-4-System mit Vorteil fuer besser platzierte Teilnehmer aus der Vorrunde.',
    bullets: [
      'Belohnt starke Vorrundenleistung.',
      'Effiziente Endrunde mit wenigen Spielen.',
      'Klare Pfade fuer Final- und Bronze-Entscheid.',
      'Besonders fuer Liga- und Masters-Endspiele geeignet.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Top-4 Qualifikation'] },
      { title: 'Zwischenrunde', steps: ['Page-Matches (1v2, 3v4)'] },
      { title: 'Endrunde', steps: ['Finale + Platzierung'] },
    ],
  },
  K5: {
    id: 'K5',
    title: 'K5 KO mit Platzierungsspiel',
    intro: 'Single-KO mit zusaetzlichen Platzierungsspielen fuer eine differenziertere Endrangliste.',
    bullets: [
      'Mehr Aussagekraft fuer Rang 3+.',
      'Zusatzmatches ausserhalb des Siegerpfads.',
      'Balanciert zwischen Geschwindigkeit und Tiefe.',
      'Geeignet fuer Vereins- und Einladungsturniere.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['KO-Hauptbaum'] },
      { title: 'Zwischenrunde', steps: ['Hauptbaum + Platzierungspfad'] },
      { title: 'Endrunde', steps: ['Finale', 'Platzierungsspiele'] },
    ],
  },
  K6: {
    id: 'K6',
    title: 'K6 Consolation',
    intro: 'Neben dem Haupt-KO gibt es ein Trostturnier fuer frueh Ausgeschiedene.',
    bullets: [
      'Mehr garantierte Spiele pro Teilnehmer.',
      'Motivierend auch nach erster Niederlage.',
      'Zwei parallele KO-Pfade.',
      'Erhoeht den organisatorischen Aufwand moderat.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Haupt-KO startet'] },
      { title: 'Zwischenrunde', steps: ['Verlierer wechseln in Consolation-Bracket'] },
      { title: 'Endrunde', steps: ['Hauptfinale + Consolation-Finale'] },
    ],
  },
  C1: {
    id: 'C1',
    title: 'C1 Gruppen -> KO',
    intro: 'Klassisches Kombiformat: erst Gruppenphase, danach KO der Qualifizierten.',
    bullets: [
      'Garantierte Vorrundenspiele fuer alle.',
      'Spannender KO-Finish fuer Top-Teams.',
      'Qualifikationslogik klar steuerbar (Top-N).',
      'Sehr verbreitetes Standardformat.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Gruppenphase'] },
      { title: 'Zwischenrunde', steps: ['Qualifikation aus Gruppen'] },
      { title: 'Endrunde', steps: ['KO-Baum bis Finale'] },
    ],
  },
  C2: {
    id: 'C2',
    title: 'C2 Swiss -> KO',
    intro: 'Swiss-Vorphase fuer gleichmaessige Paarungen, danach KO-Endrunde fuer die besten Teilnehmer.',
    bullets: [
      'Swiss reduziert Gruppenartefakte.',
      'Top-Feld wird im KO klar entschieden.',
      'Sehr geeignet bei grosser Teilnehmerzahl.',
      'Guter Mix aus Fairness und Showdown.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Swiss-Runden (1..n)'] },
      { title: 'Zwischenrunde', steps: ['Cutline / Qualifikationsgrenze'] },
      { title: 'Endrunde', steps: ['KO-Endrunde'] },
    ],
  },
  C3: {
    id: 'C3',
    title: 'C3 Liga -> Page',
    intro: 'Erst Ligaphase fuer eine robuste Rangfolge, dann kompakte Page-Playoff-Endrunde fuer die Top-4.',
    bullets: [
      'Liga bestimmt faire Ausgangslage.',
      'Page-System belohnt starke Ligaplatzierung.',
      'Wenige, aber entscheidende Endrundenspiele.',
      'Besonders fuer Meisterschaftsfinals geeignet.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Ligaphase'] },
      { title: 'Zwischenrunde', steps: ['Top-4 fuer Page qualifizieren'] },
      { title: 'Endrunde', steps: ['Page-Playoff + Finale'] },
    ],
  },
  C4: {
    id: 'C4',
    title: 'C4 Gruppen -> Double Elim',
    intro: 'Gruppenphase zur Selektion, danach Double-Elimination fuer eine belastbare Endentscheidung.',
    bullets: [
      'Starker Mittelweg aus Breite und Tiefe.',
      'Top-Teilnehmer haben zweite Chance.',
      'Hoeherer Matchumfang in der Endrunde.',
      'Geeignet fuer Events mit ausreichend Zeit.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Gruppenphase'] },
      { title: 'Zwischenrunde', steps: ['Qualifikation ins Double-KO'] },
      { title: 'Endrunde', steps: ['Winner/Loser Bracket + Grand Final'] },
    ],
  },
  C5: {
    id: 'C5',
    title: 'C5 Mehrstufig',
    intro: 'Mehrere Gruppenstufen vor der KO-Entscheidung. Fokus auf strukturierter Reduktion grosser Teilnehmerfelder.',
    bullets: [
      'Mehrstufige Qualifikation (z. B. Vor- und Zwischenrunde).',
      'Sehr gute Skalierung bei grossen Feldern.',
      'Hohe Planungsdisziplin notwendig.',
      'Am Ende klarer KO-Showdown.',
    ],
    flow: [
      { title: 'Vorrunde', steps: ['Gruppenstufe 1'] },
      { title: 'Zwischenrunde', steps: ['Gruppenstufe 2 / Zwischenrunde'] },
      { title: 'Endrunde', steps: ['KO-Endrunde'] },
    ],
  },
};

const MODE_VARIANT_VALUES = new Set<string>(Object.keys(MODE_VARIANT_INSIGHTS));

export const isTournamentModeVariant = (value: string): value is TournamentModeVariant =>
  MODE_VARIANT_VALUES.has(value);

export const getModeVariantInsight = (variant: string | null | undefined): ModeVariantInsight | null => {
  if (!variant || !isTournamentModeVariant(variant)) {
    return null;
  }
  return MODE_VARIANT_INSIGHTS[variant];
};
