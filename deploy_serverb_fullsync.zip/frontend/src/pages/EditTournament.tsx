// Edit Tournament Page
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { tournamentService } from '../services/tournamentService';
import { authService } from '../services/authService';
import { participantService } from '../services/participantService';
import { qualificationService } from '../services/qualificationService';
import { locationService } from '../services/locationService';
import { Participant, LeagueVariant, KOStartRound, QualificationPlan, Location, KOStructure, TournamentModeVariant, KOPairingVariant } from '../types';
import { Button, Card, CardContent, CardHeader, CardTitle, Input, Textarea } from '../components/ui';
import { cn } from '@/lib/utils';
import { ArrowLeft } from 'phosphor-react';
import TournamentModeVisualization from '../components/tournament/TournamentModeVisualization';
import { MODE_VARIANTS, PAIRING_VARIANTS } from '../domain/tournamentModeMatrix';
import { getModeVariantInsight } from '../domain/tournamentModeInsights';

export default function EditTournament() {
  type KODrawModeValue = 'random_first_round' | 'random_each_round' | 'predefined_slots' | 'cross' | 'draw';

  const navigate = useNavigate();
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const tournamentId = id ? parseInt(id) : 0;
  const [loading, setLoading] = useState(false);
  const [loadingTournament, setLoadingTournament] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [allParticipants, setAllParticipants] = useState<Participant[]>([]);
  const [loadingParticipants, setLoadingParticipants] = useState(false);
  const [qualificationPlan, setQualificationPlan] = useState<QualificationPlan | null>(null);
  const [loadingQualificationPlan, setLoadingQualificationPlan] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    organizer: '',
    description: '',
    start_date: '',
    end_date: '',
    play_time_start: '',
    play_time_end: '',
    match_duration_minutes: 0,
    mode: 'round_robin' as 'round_robin' | 'knockout' | 'combined',
    mode_variant: 'L1' as TournamentModeVariant,
    has_group_phase: true,
    groups_count: 2,
    participants_per_group: null as number | null,
    group_distribution: 'random' as 'random' | 'seeded',
    has_ko_phase: false,
    ko_participants: 4,  // Legacy
    ko_first_round_size: 4,  // Legacy
    ko_start_round: null as KOStartRound | null,
    ko_fallback_qualifiers: null as Array<{position: number; count: number; selection: 'best'}> | null,
    ko_distribution: 'random_first_round' as KODrawModeValue,  // Deprecated, kept for backward compatibility
    ko_pairing_mode: 'P1' as KOPairingVariant,
    ko_structure: null as KOStructure | null,
    ko_draw_method: null as 'fixed_cross' | 'same_position_cross' | 'overall_seeding' | 'pot_system' | 'full_random' | 'bonus_draw_for_winners' | 'predefined_bracket' | 'manual' | null,
    ko_third_place_match: false,
    ko_group_winner_advantage: false,
    ko_block_same_group: true,
    ko_block_same_position: false,
    ko_random_seed: null as number | null,
    league_scoring_system: null as 'points' | 'difference' | null,
    tie_breaking_rules: [] as string[],
    league_variant: 'classic' as LeagueVariant,
    league_rounds_multiplier: 1,
    is_template: false,
    visibility: 'public' as 'public' | 'shared' | 'private',
    seeded_participant_ids: [] as number[],
    location_id: null as number | null,
    spielfeld_assignment_mode: 'random' as 'random' | 'group_fixed' | 'group_random',
    temporary_spielfelder_count: 0,
  });
  const [locations, setLocations] = useState<Location[]>([]);

  useEffect(() => {
    if (!authService.isAuthenticated()) {
      navigate('/login');
      return;
    }
    if (!id || tournamentId <= 0) {
      setLoadingTournament(false);
      setError(t('tournament.edit.invalidId'));
      return;
    }
    loadTournament();
  }, [navigate, tournamentId, id]);

  useEffect(() => {
    const loadLocations = async () => {
      try {
        const list = await locationService.getAll();
        setLocations(list);
      } catch {
        setLocations([]);
      }
    };
    loadLocations();
  }, []);

  // Load tournament data on mount
  const loadTournament = async () => {
    try {
      setLoadingTournament(true);
      const tournament = await tournamentService.getById(tournamentId);
      
      // Populate form with tournament data
      setFormData({
        name: tournament.name,
        organizer: tournament.organizer || '',
        description: tournament.description || '',
        start_date: tournament.start_date,
        end_date: tournament.end_date || '',
        play_time_start: tournament.play_time_start || '',
        play_time_end: tournament.play_time_end || '',
        match_duration_minutes: tournament.match_duration_minutes || 0,
        mode: tournament.mode,
        mode_variant: tournament.mode_variant || 'L1',
        has_group_phase: tournament.has_group_phase,
        groups_count: tournament.groups_count || 2,
        participants_per_group: tournament.participants_per_group || null,
        group_distribution: tournament.group_distribution as 'random' | 'seeded',
        has_ko_phase: tournament.has_ko_phase,
        ko_participants: tournament.ko_participants || 4,
        ko_first_round_size: tournament.ko_first_round_size || 4,
        ko_start_round: tournament.ko_start_round || null,
        ko_fallback_qualifiers: tournament.ko_fallback_qualifiers || null,
        ko_distribution: normalizeDrawMode(tournament.ko_distribution),
        ko_pairing_mode: tournament.ko_pairing_mode || 'P1',
        ko_structure: tournament.ko_structure,
        ko_draw_method: tournament.ko_draw_method,
        ko_third_place_match: tournament.ko_third_place_match || false,
        ko_group_winner_advantage: tournament.ko_group_winner_advantage || false,
        ko_block_same_group: tournament.ko_block_same_group !== undefined ? tournament.ko_block_same_group : true,
        ko_block_same_position: tournament.ko_block_same_position || false,
        ko_random_seed: tournament.ko_random_seed,
        league_scoring_system: tournament.league_scoring_system,
        tie_breaking_rules: tournament.tie_breaking_rules || [],
        league_variant: tournament.league_variant || 'classic',
        league_rounds_multiplier: tournament.league_rounds_multiplier || 1,
        is_template: false,
        visibility: (tournament as any).visibility || 'public',
        seeded_participant_ids: tournament.seeded_participant_ids || [],
        location_id: tournament.location_id ?? null,
        spielfeld_assignment_mode: (tournament.spielfeld_assignment_mode as 'random' | 'group_fixed' | 'group_random') || 'random',
        temporary_spielfelder_count: tournament.temporary_spielfelder_count ?? 0,
      });
    } catch (err) {
      console.error('Failed to load tournament:', err);
      setError(t('tournament.edit.loadError'));
      navigate('/dashboard');
    } finally {
      setLoadingTournament(false);
    }
  };

  // Load participants when seeded distribution is selected
  useEffect(() => {
    if (formData.group_distribution === 'seeded' && formData.groups_count > 1) {
      const loadParticipants = async () => {
        try {
          setLoadingParticipants(true);
          const participants = await participantService.getAll();
          setAllParticipants(participants);
        } catch (err) {
          console.error('Failed to load participants:', err);
        } finally {
          setLoadingParticipants(false);
        }
      };
      loadParticipants();
    }
  }, [formData.group_distribution, formData.groups_count]);

  // Auto-set has_group_phase and has_ko_phase based on mode
  useEffect(() => {
    if (formData.mode === 'round_robin') {
      setFormData(prev => ({ ...prev, has_group_phase: true, has_ko_phase: false }));
    } else if (formData.mode === 'knockout') {
      setFormData(prev => ({ ...prev, has_group_phase: false, has_ko_phase: true }));
    } else if (formData.mode === 'combined') {
      setFormData(prev => ({ ...prev, has_group_phase: true, has_ko_phase: true }));
    }
  }, [formData.mode]);

  // Handle exclusive logic: decision_match vs other rules
  useEffect(() => {
    const hasDecisionMatch = formData.tie_breaking_rules.includes('decision_match');
    const hasOtherRules = formData.tie_breaking_rules.some(r => r !== 'decision_match');
    
    if (hasDecisionMatch && hasOtherRules) {
      setFormData(prev => ({
        ...prev,
        tie_breaking_rules: ['decision_match']
      }));
    }
  }, [formData.tie_breaking_rules]);

  // Calculate qualification plan when groups_count or ko_start_round changes
  useEffect(() => {
    if (formData.mode === 'combined' && formData.has_group_phase && formData.groups_count > 0 && formData.ko_start_round) {
      const calculatePlan = async () => {
        try {
          setLoadingQualificationPlan(true);
          const plan = await qualificationService.calculateQualificationPlan(
            formData.groups_count,
            formData.ko_start_round!
          );
          setQualificationPlan(plan);
          setFormData(prev => ({
            ...prev,
            ko_fallback_qualifiers: plan.fallback_rules.length > 0 ? plan.fallback_rules : null,
            ko_participants: plan.required_participants,
            ko_first_round_size: plan.required_participants,
          }));
        } catch (err) {
          console.error('Failed to calculate qualification plan:', err);
          setQualificationPlan(null);
        } finally {
          setLoadingQualificationPlan(false);
        }
      };
      calculatePlan();
    } else {
      setQualificationPlan(null);
    }
  }, [formData.mode, formData.has_group_phase, formData.groups_count, formData.ko_start_round]);

  // Migrate legacy data: if ko_start_round is null but ko_first_round_size is set
  useEffect(() => {
    if (formData.mode === 'combined' && !formData.ko_start_round && formData.ko_first_round_size) {
      let migratedRound: KOStartRound | null = null;
      if (formData.ko_first_round_size === 32) migratedRound = 'round_of_32';
      else if (formData.ko_first_round_size === 16) migratedRound = 'round_of_16';
      else if (formData.ko_first_round_size === 8) migratedRound = 'quarterfinal';
      else if (formData.ko_first_round_size === 4) migratedRound = 'semifinal';
      else if (formData.ko_first_round_size === 2) migratedRound = 'final';
      
      if (migratedRound) {
        setFormData(prev => ({
          ...prev,
          ko_start_round: migratedRound,
        }));
      }
    }
  }, [formData.mode, formData.ko_start_round, formData.ko_first_round_size]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : (value === '' ? null : value)
    }));
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (formData.mode === 'round_robin' || (formData.mode === 'combined' && formData.has_group_phase)) {
      if (!formData.league_scoring_system) {
        setError(t('tournament.create.validation.scoringRequired'));
        setLoading(false);
        return;
      }
      if (!formData.tie_breaking_rules || formData.tie_breaking_rules.length === 0) {
        setError(t('tournament.create.validation.tieBreakingRequired'));
        setLoading(false);
        return;
      }
    }

    if (formData.mode === 'round_robin' && formData.league_variant === 'multiple') {
      if (!formData.league_rounds_multiplier || formData.league_rounds_multiplier < 2 || formData.league_rounds_multiplier > 10) {
        setError(t('tournament.create.validation.multiplierRange'));
        setLoading(false);
        return;
      }
    }

    if (formData.group_distribution === 'seeded' && formData.groups_count > 1) {
      if (!formData.seeded_participant_ids || formData.seeded_participant_ids.length === 0) {
        setError(t('tournament.create.validation.seededRequired'));
        setLoading(false);
        return;
      }
    }

    try {
      await tournamentService.update(tournamentId, {
        name: formData.name,
        organizer: formData.organizer || undefined,
        description: formData.description || undefined,
        start_date: formData.start_date,
        end_date: formData.end_date || undefined,
        play_time_start: formData.play_time_start || undefined,
        play_time_end: formData.play_time_end || undefined,
        match_duration_minutes: formData.match_duration_minutes > 0 ? Number(formData.match_duration_minutes) : 0,
        mode: formData.mode,
        mode_variant: formData.mode_variant,
        has_group_phase: formData.has_group_phase,
        groups_count: formData.has_group_phase ? formData.groups_count : 0,
        participants_per_group: formData.has_group_phase ? formData.participants_per_group : undefined,
        group_distribution: formData.has_group_phase ? formData.group_distribution : 'random',
        has_ko_phase: formData.has_ko_phase,
        ko_participants: (formData.has_ko_phase && formData.mode === 'combined') ? formData.ko_participants : 0,
        ko_first_round_size: formData.has_ko_phase ? parseInt(formData.ko_first_round_size.toString()) : undefined,
        ko_start_round: formData.has_ko_phase && formData.mode === 'combined' ? (formData.ko_start_round as any) : undefined,
        ko_fallback_qualifiers: formData.has_ko_phase && formData.mode === 'combined' ? (formData.ko_fallback_qualifiers as any) : undefined,
        ko_distribution: formData.has_ko_phase ? formData.ko_distribution : undefined,
        ko_pairing_mode: formData.has_ko_phase ? formData.ko_pairing_mode : undefined,
        ko_structure: formData.has_ko_phase ? formData.ko_structure : undefined,
        ko_draw_method: formData.has_ko_phase ? formData.ko_draw_method : undefined,
        ko_third_place_match: formData.has_ko_phase ? formData.ko_third_place_match : false,
        ko_group_winner_advantage: formData.has_ko_phase ? formData.ko_group_winner_advantage : false,
        ko_block_same_group: formData.has_ko_phase ? formData.ko_block_same_group : true,
        ko_block_same_position: formData.has_ko_phase ? formData.ko_block_same_position : false,
        ko_random_seed: formData.has_ko_phase && formData.ko_random_seed ? formData.ko_random_seed : undefined,
        league_scoring_system: (formData.mode === 'round_robin' || formData.mode === 'combined') ? formData.league_scoring_system : undefined,
        tie_breaking_rules: (formData.mode === 'round_robin' || formData.mode === 'combined') && formData.tie_breaking_rules.length > 0 ? formData.tie_breaking_rules : undefined,
        league_variant: formData.mode === 'round_robin' ? formData.league_variant : undefined,
        league_rounds_multiplier: formData.mode === 'round_robin' && formData.league_variant === 'multiple' ? formData.league_rounds_multiplier : undefined,
        seeded_participant_ids: formData.group_distribution === 'seeded' && formData.seeded_participant_ids.length > 0 ? formData.seeded_participant_ids : undefined,
        visibility: formData.visibility,
        location_id: formData.location_id || undefined,
        spielfeld_assignment_mode: formData.location_id ? formData.spielfeld_assignment_mode : undefined,
        temporary_spielfelder_count: formData.location_id ? 0 : (formData.temporary_spielfelder_count || 0),
      });
      navigate(`/tournaments/${tournamentId}`);
    } catch (err: any) {
      setError(err.response?.data?.detail || t('tournament.edit.error'));
    } finally {
      setLoading(false);
    }
  };

  const modeExplanations = {
    round_robin: {
      title: t('tournament.mode.roundRobinEdit.title'),
      description: t('tournament.mode.roundRobinEdit.description'),
      features: [
        t('tournament.mode.roundRobin.features.allPlay'),
        t('tournament.mode.roundRobinEdit.features.groupPhase'),
        t('tournament.mode.roundRobinEdit.features.ranking'),
        t('tournament.mode.roundRobin.features.noKO'),
        t('tournament.mode.roundRobinEdit.features.suitable'),
      ]
    },
    knockout: {
      title: t('tournament.mode.knockout.title'),
      description: t('tournament.mode.knockout.description'),
      features: [
        t('tournament.mode.knockout.features.direct'),
        t('tournament.mode.knockout.features.losers'),
        t('tournament.mode.knockout.features.quick'),
        t('tournament.mode.knockout.features.bronze'),
        t('tournament.mode.knockout.features.suitable'),
      ]
    },
    combined: {
      title: t('tournament.mode.combined.title'),
      description: t('tournament.mode.combined.description'),
      features: [
        t('tournament.mode.combined.features.phase1'),
        t('tournament.mode.combined.features.qualify'),
        t('tournament.mode.combined.features.phase2'),
        t('tournament.mode.combined.features.bronze'),
        t('tournament.mode.combined.features.suitable'),
      ]
    }
  };

  const currentVariantInsight = getModeVariantInsight(formData.mode_variant);
  const currentMode = currentVariantInsight
    ? {
        title: currentVariantInsight.title,
        description: currentVariantInsight.intro,
        features: currentVariantInsight.bullets,
      }
    : modeExplanations[formData.mode];

  const tieBreakingRuleLabels: Record<string, string> = {
    'wins': t('common.tieBreaking.wins'),
    'diff': t('common.tieBreaking.diff'),
    'goals_for': t('common.tieBreaking.goalsFor'),
    'direct_encounter': t('common.tieBreaking.directEncounter'),
    'decision_match': t('common.tieBreaking.decisionMatch'),
  };

  const koStartRoundLabels: Record<string, string> = {
    round_of_32: t('common.koStartRound.roundOf32'),
    round_of_16: t('common.koStartRound.roundOf16'),
    quarterfinal: t('common.koStartRound.quarterfinal'),
    semifinal: t('common.koStartRound.semifinal'),
    final: t('common.koStartRound.final'),
  };

  const groupDistributionLabels: Record<string, string> = {
    random: t('common.groupDistribution.random'),
    seeded: t('common.groupDistribution.seeded'),
  };

  const getAvailableTieBreakingRules = () => {
    return ['wins', 'diff', 'goals_for', 'direct_encounter', 'decision_match'];
  };

  const moveTieBreakingRule = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === formData.tie_breaking_rules.length - 1) return;
    
    const newRules = [...formData.tie_breaking_rules];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    [newRules[index], newRules[newIndex]] = [newRules[newIndex], newRules[index]];
    
    setFormData(prev => ({
      ...prev,
      tie_breaking_rules: newRules
    }));
  };

  const normalizeDrawMode = (value: string | null | undefined): KODrawModeValue => {
    if (!value || value === 'cross' || value === 'draw') {
      return 'random_first_round';
    }
    return value as KODrawModeValue;
  };

  const deriveDrawMethodFromPairing = (pairing: KOPairingVariant) => {
    if (pairing === 'P2') return 'overall_seeding';
    if (pairing === 'P3') return 'fixed_cross';
    if (pairing === 'P5') return 'pot_system';
    if (pairing === 'P6') return 'manual';
    return 'full_random';
  };

  const variantToPreset = (variant: TournamentModeVariant) => {
    const base = MODE_VARIANTS.find((item) => item.id === variant);
    const mode = base?.baseMode ?? 'round_robin';
    const presets: Partial<typeof formData> = {
      mode,
      has_group_phase: mode !== 'knockout',
      has_ko_phase: mode !== 'round_robin',
      league_variant: variant === 'L2' ? 'double' : (variant === 'L4' || variant === 'C2' ? 'multiple' : 'classic'),
      ko_structure:
        variant === 'K2' || variant === 'C4' ? 'double_elimination' :
        variant === 'K3' ? 'triple_elimination' :
        variant === 'K4' || variant === 'C3' ? 'page_playoff' :
        variant === 'K5' ? 'single_elimination_with_third' :
        variant === 'K6' ? 'consolation_bracket' :
        variant === 'C5' ? 'group_then_single_ko' :
        mode === 'round_robin' ? null : 'single_elimination',
    };
    return presets;
  };

  const koStructureOptions = [
    { 
      value: 'single_elimination', 
      label: t('tournament.ko.structure.singleElimination'), 
      description: t('tournament.ko.structure.singleEliminationDesc') 
    },
    { 
      value: 'single_elimination_with_third', 
      label: t('tournament.ko.structure.singleEliminationWithThird'), 
      description: t('tournament.ko.structure.singleEliminationWithThirdDesc') 
    },
    { 
      value: 'consolation_bracket', 
      label: t('tournament.ko.structure.consolationBracket'), 
      description: t('tournament.ko.structure.consolationBracketDesc') 
    },
    { 
      value: 'double_elimination', 
      label: t('tournament.ko.structure.doubleElimination'), 
      description: t('tournament.ko.structure.doubleEliminationDesc') 
    },
    { 
      value: 'triple_elimination', 
      label: t('tournament.ko.structure.tripleElimination'), 
      description: t('tournament.ko.structure.tripleEliminationDesc') 
    },
    { 
      value: 'aggregate_ko', 
      label: t('tournament.ko.structure.aggregateKo'), 
      description: t('tournament.ko.structure.aggregateKoDesc') 
    },
    { 
      value: 'group_then_single_ko', 
      label: t('tournament.ko.structure.groupThenSingleKo'), 
      description: t('tournament.ko.structure.groupThenSingleKoDesc') 
    },
    { 
      value: 'group_then_double_ko', 
      label: t('tournament.ko.structure.groupThenDoubleKo'), 
      description: t('tournament.ko.structure.groupThenDoubleKoDesc') 
    },
    { 
      value: 'ko_with_group_winner_advantage', 
      label: t('tournament.ko.structure.koWithGroupAdvantage'), 
      description: t('tournament.ko.structure.koWithGroupAdvantageDesc') 
    },
    { 
      value: 'page_playoff', 
      label: t('tournament.ko.structure.pagePlayoff'), 
      description: t('tournament.ko.structure.pagePlayoffDesc') 
    },
  ];

  const koOnlyDrawMethods = [
    { 
      value: 'full_random', 
      label: t('tournament.ko.draw.fullRandom'), 
      description: t('tournament.ko.draw.fullRandomDesc') 
    },
    { 
      value: 'pot_system', 
      label: t('tournament.ko.draw.potSystem'), 
      description: t('tournament.ko.draw.potSystemDesc') 
    },
    { 
      value: 'manual', 
      label: t('tournament.ko.draw.manual'), 
      description: t('tournament.ko.draw.manualKODesc') 
    }
  ];

  const combinedDrawMethods = [
    { 
      value: 'fixed_cross', 
      label: t('tournament.ko.draw.fixedCross'), 
      description: t('tournament.ko.draw.fixedCrossDesc') 
    },
    { 
      value: 'same_position_cross', 
      label: t('tournament.ko.draw.samePositionCross'), 
      description: t('tournament.ko.draw.samePositionCrossDesc') 
    },
    { 
      value: 'overall_seeding', 
      label: t('tournament.ko.draw.overallSeeding'), 
      description: t('tournament.ko.draw.overallSeedingDesc') 
    },
    { 
      value: 'pot_system', 
      label: t('tournament.ko.draw.potSystem'), 
      description: t('tournament.ko.draw.potSystemGroupDesc') 
    },
    { 
      value: 'full_random', 
      label: t('tournament.ko.draw.fullRandom'), 
      description: t('tournament.ko.draw.fullRandomQualifiedDesc') 
    },
    { 
      value: 'bonus_draw_for_winners', 
      label: t('tournament.ko.draw.bonusDrawForWinners'), 
      description: t('tournament.ko.draw.bonusDrawForWinnersDesc') 
    },
    { 
      value: 'predefined_bracket', 
      label: t('tournament.ko.draw.predefinedBracket'), 
      description: t('tournament.ko.draw.predefinedBracketDesc') 
    },
    { 
      value: 'manual', 
      label: t('tournament.ko.draw.manual'), 
      description: t('tournament.ko.draw.manualCombinedDesc') 
    }
  ];

  const koDrawModeOptions = [
    {
      value: 'random_first_round',
      label: t('tournament.ko.drawMode.randomFirst'),
      description: t('tournament.ko.drawMode.randomFirstDesc')
    },
    {
      value: 'random_each_round',
      label: t('tournament.ko.drawMode.randomEachRound'),
      description: t('tournament.ko.drawMode.randomEachRoundDesc')
    },
    {
      value: 'predefined_slots',
      label: t('tournament.ko.drawMode.predefinedSlots'),
      description: t('tournament.ko.drawMode.predefinedSlotsDesc')
    }
  ];

  const getAllowedKOStructures = (mode: string) => {
    if (mode === 'combined') {
      return koStructureOptions.filter(option => 
        ['single_elimination', 'single_elimination_with_third', 'consolation_bracket', 'double_elimination', 'triple_elimination', 'aggregate_ko'].includes(option.value)
      );
    } else if (mode === 'knockout') {
      return koStructureOptions.filter(option => 
        !['group_then_single_ko', 'group_then_double_ko', 'ko_with_group_winner_advantage'].includes(option.value)
      );
    }
    return [];
  };

  const needsDrawMethod = (structure: string | null, _drawMethod: string | null) => {
    if (!structure) return false;
    return true;
  };

  const needsKoDistribution = (pairing: KOPairingVariant, drawMethod: string | null) => {
    if (drawMethod === 'manual') return false;
    return ['P1', 'P2', 'P5', 'P7'].includes(pairing);
  };

  const needsGroupWinnerAdvantage = (_structure: string | null, _mode: string) => {
    return false;
  };

  const getKoStructureLabel = (value: string | null) => {
    if (!value) return null;
    const found = koStructureOptions.find(o => o.value === value);
    return found ? found.label : value;
  };

  const getKoDrawMethodLabel = (value: string | null) => {
    if (!value) return null;
    const list = [...combinedDrawMethods, ...koOnlyDrawMethods];
    const found = list.find(o => o.value === value);
    return found ? found.label : value;
  };

  const tieRulesLabel = (formData.tie_breaking_rules || [])
    .map((rule) => tieBreakingRuleLabels[rule] || rule)
    .join(' > ');

  const groupSettingsSummary: string[] = [];
  if (formData.has_group_phase) {
    if (formData.groups_count) {
      groupSettingsSummary.push(t('tournament.overview.groups', { count: formData.groups_count }));
    }
    if (formData.participants_per_group) {
      groupSettingsSummary.push(t('tournament.overview.participantsPerGroup', { count: formData.participants_per_group }));
    }
    if (formData.group_distribution) {
      const label = groupDistributionLabels[formData.group_distribution] || formData.group_distribution;
      groupSettingsSummary.push(t('tournament.overview.distribution', { label }));
    }
    if (formData.league_scoring_system) {
      groupSettingsSummary.push(t('tournament.overview.scoring', { system: formData.league_scoring_system === 'points' ? t('common.scoring.points') : t('common.scoring.difference') }));
    }
    if (tieRulesLabel) {
      groupSettingsSummary.push(t('tournament.overview.tieBreaking', { rules: tieRulesLabel }));
    }
  }

  const koSettingsSummary: string[] = [];
  if (formData.has_ko_phase) {
    if (formData.ko_start_round) {
      const label = koStartRoundLabels[formData.ko_start_round] || formData.ko_start_round;
      koSettingsSummary.push(t('tournament.overview.koStart', { round: label }));
    } else if (formData.ko_first_round_size) {
      koSettingsSummary.push(t('tournament.overview.koSize', { size: formData.ko_first_round_size }));
    }
    const structureLabel = getKoStructureLabel(formData.ko_structure);
    if (structureLabel) {
      koSettingsSummary.push(t('tournament.overview.structure', { label: structureLabel }));
    }
    const drawLabel = getKoDrawMethodLabel(formData.ko_draw_method);
    if (drawLabel) {
      koSettingsSummary.push(t('tournament.overview.draw', { label: drawLabel }));
    }
  }

  return (
    <div className="p-8 flex gap-8 max-w-[1400px] mx-auto bg-background min-h-screen">
      {/* Linke Seite - Formular */}
      <div className="flex-1">
        <div className="flex justify-between mb-8 items-center">
          <h1 className="m-0 text-foreground">{t('tournament.edit.title')}</h1>
          <Button variant="secondary" onClick={() => navigate(`/tournaments/${tournamentId}`)}>
            <ArrowLeft size={20} className="mr-2 align-middle" />
            {t('common.back')}
          </Button>
        </div>

        {loadingTournament && (
          <div className="p-8 text-center text-muted-foreground">{t('tournament.edit.loading')}</div>
        )}

        {error && (
          <div className="p-4 bg-destructive/20 text-destructive rounded-lg mb-4 border border-destructive">
            {error}
          </div>
        )}

        {!loadingTournament && (
          <div className="mb-6 p-4 bg-warning/20 rounded-lg border border-warning">
            <p className="m-0 text-sm text-warning">
              <strong>Hinweis:</strong> {t('tournament.edit.configWarning')}
            </p>
          </div>
        )}

        {!loadingTournament && (
        <Card>
          <CardContent className="p-8">
        <form onSubmit={handleSubmit}>
          <Input
            label={t('tournament.create.name')}
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <Input
            label="Veranstalter (optional)"
            type="text"
            name="organizer"
            value={formData.organizer || ''}
            onChange={handleChange}
          />

          <Textarea
            label={t('tournament.create.description')}
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={3}
          />

          <div className="grid grid-cols-2 gap-4 mb-6">
            <Input
              label={t('tournament.create.startDate')}
              type="date"
              name="start_date"
              value={formData.start_date}
              onChange={handleChange}
              required
            />
            <Input
              label={t('tournament.create.endDate')}
              type="date"
              name="end_date"
              value={formData.end_date}
              onChange={handleChange}
            />
          </div>

          <div className="mb-6 rounded-lg border border-border bg-card p-4">
            <div className="mb-2 font-semibold text-foreground">Spielzeitplanung (optional)</div>
            <p className="mb-3 text-sm text-muted-foreground">
              Definiert Zeitfenster und Dauer pro Match. Der Spielplan nutzt diese Werte für automatische Zeit-Slots.
            </p>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <Input
                label="Startzeit"
                type="time"
                name="play_time_start"
                value={formData.play_time_start || ''}
                onChange={handleChange}
              />
              <Input
                label="Endzeit"
                type="time"
                name="play_time_end"
                value={formData.play_time_end || ''}
                onChange={handleChange}
              />
              <Input
                label="Zeit pro Spiel (Min.)"
                type="number"
                name="match_duration_minutes"
                value={formData.match_duration_minutes}
                min={0}
                max={600}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    match_duration_minutes: Math.max(0, Math.min(600, parseInt(e.target.value || '0', 10) || 0)),
                  }))
                }
              />
            </div>
          </div>

          <div className="mb-6">
            <label className="block mb-2 font-bold text-foreground">
              {t('tournament.create.location')}
            </label>
            <select
              name="location_id"
              value={formData.location_id ?? ''}
              onChange={(e) => setFormData(prev => ({ ...prev, location_id: e.target.value === '' ? null : Number(e.target.value) }))}
              className="w-full p-3 text-base bg-muted text-foreground border border-border rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <option value="">{t('common.noLocation')}</option>
              {(locations ?? []).map(loc => (
                <option key={loc.id} value={loc.id}>{loc.name}</option>
              ))}
            </select>
            <div className="mt-4 rounded-lg border border-border bg-card p-4">
              <div className="mb-2 font-semibold text-foreground">Temporäre Spielfelder (ohne globalen Spielort)</div>
              <p className="mb-3 text-sm text-muted-foreground">
                Du hast drei Optionen:
                <span className="block mt-1">1) Fester Spielort wählen, dann werden dessen Spielfelder verwendet.</span>
                <span className="block">2) Kein Spielort und Anzahl &gt; 0, dann werden temporäre Spielfelder 1 bis n verwendet.</span>
                <span className="block">3) Kein Spielort und Anzahl 0, dann wird der Spielplan ohne Spielfeldzuweisung erstellt.</span>
              </p>
              <input
                type="number"
                min={0}
                max={64}
                value={formData.temporary_spielfelder_count}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    temporary_spielfelder_count: Math.max(0, Math.min(64, parseInt(e.target.value || '0', 10) || 0)),
                  }))
                }
                className="w-full rounded-md border border-border bg-muted px-3 py-2 text-foreground"
              />
              <p className="mt-2 text-xs text-muted-foreground">
                Priorität: fester Spielort, danach temporäre Spielfelder, sonst ohne Spielfelder.
              </p>
            </div>
            {formData.location_id != null && (formData.mode === 'round_robin' || formData.mode === 'combined') && (
              <div className="mt-4">
                <label className="block mb-2 font-bold text-foreground">
                  {t('tournament.create.spielfeldAssignment')}
                </label>
                <select
                  name="spielfeld_assignment_mode"
                  value={formData.spielfeld_assignment_mode}
                  onChange={(e) => setFormData(prev => ({ ...prev, spielfeld_assignment_mode: e.target.value as 'random' | 'group_fixed' | 'group_random' }))}
                  className="w-full p-3 text-base bg-muted text-foreground border border-border rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="random">{t('common.spielfeldAssignment.random')}</option>
                  <option value="group_fixed">{t('common.spielfeldAssignment.groupFixed')}</option>
                  <option value="group_random">{t('common.spielfeldAssignment.groupRandom')}</option>
                </select>
              </div>
            )}
          </div>

          <div className="mb-6">
            <label className="block mb-2 font-bold text-foreground">
              Modusvariante (L/K/C)
            </label>
            <select
              value={formData.mode_variant}
              onChange={(e) => {
                const nextVariant = e.target.value as TournamentModeVariant;
                setFormData((prev) => ({
                  ...prev,
                  mode_variant: nextVariant,
                  ...variantToPreset(nextVariant),
                }));
              }}
              className="w-full p-3 mb-3 text-base bg-muted text-foreground border border-border rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              {MODE_VARIANTS.map((variant) => (
                <option key={variant.id} value={variant.id}>
                  {variant.title}
                </option>
              ))}
            </select>
            <label className="block mb-2 font-bold text-foreground">
              {t('tournament.create.mode')}
            </label>
            <select
              name="mode"
              value={formData.mode}
              onChange={handleChange}
              required
              className="w-full p-3 text-base bg-muted text-foreground border border-border rounded-md outline-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              <option value="round_robin">{t('common.mode.roundRobin')}</option>
              <option value="knockout">{t('common.mode.knockout')}</option>
              <option value="combined">{t('common.mode.combined')}</option>
            </select>
          </div>

        {(formData.mode === 'round_robin' || formData.mode === 'combined') && (
          <div className="mb-4 ml-0">
            <h3 className="mb-2 font-bold text-foreground">{t('tournament.create.groupPhase')}</h3>
            <div className="ml-8">
              <Input
                label={t('tournament.create.groupsCount')}
                type="number"
                name="groups_count"
                value={formData.groups_count}
                onChange={handleChange}
                min={1}
              />
            
            {formData.groups_count > 1 && (
              <>
                <label className="block mt-4 mb-2 text-foreground">
                  {t('tournament.create.drawType')}
                </label>
                <select
                  name="group_distribution"
                  value={formData.group_distribution}
                  onChange={handleChange}
                  className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="random">{t('common.groupDistribution.randomLabel')}</option>
                  <option value="seeded">{t('common.groupDistribution.seededLabel')}</option>
                </select>

                {formData.group_distribution === 'seeded' && (
                  <div className="mt-4 p-4 bg-card rounded-lg border border-border">
                    <label className="block mb-2 font-bold text-foreground">
                      {t('tournament.create.seededPlayers')}
                    </label>
                    <p className="mb-3 text-sm text-muted-foreground">
                      {t('tournament.create.seededHint')}
                    </p>
                    {loadingParticipants ? (
                      <div className="p-4 text-center text-muted-foreground">{t('tournament.create.loadingParticipants')}</div>
                    ) : allParticipants.length === 0 ? (
                      <div className="p-4 text-center text-muted-foreground">
                        {t('tournament.create.noParticipants')}
                      </div>
                    ) : (
                      <>
                        <div className="max-h-[300px] overflow-y-auto border border-border rounded-lg p-2">
                          {allParticipants.map(participant => {
                            const isSelected = formData.seeded_participant_ids.includes(participant.id);
                            return (
                              <label
                                key={participant.id}
                                className={cn(
                                  "flex items-center gap-2 p-2 cursor-pointer rounded-lg mb-1",
                                  isSelected && "bg-primary/10"
                                )}
                              >
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setFormData(prev => ({
                                        ...prev,
                                        seeded_participant_ids: [...prev.seeded_participant_ids, participant.id]
                                      }));
                                    } else {
                                      setFormData(prev => ({
                                        ...prev,
                                        seeded_participant_ids: prev.seeded_participant_ids.filter(id => id !== participant.id)
                                      }));
                                    }
                                  }}
                                />
                                <span className="text-foreground">
                                  {participant.first_name} {participant.last_name}
                                  {participant.club && ` (${participant.club})`}
                                  {participant.nickname && ` - "${participant.nickname}"`}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                        <p className={cn(
                          "mt-2 text-sm",
                          formData.seeded_participant_ids.length === 0 ? "text-destructive" : "text-muted-foreground"
                        )}>
                          {formData.seeded_participant_ids.length === 0 
                            ? t('tournament.create.seededNone')
                            : t('tournament.create.seededCount', { count: formData.seeded_participant_ids.length })
                          }
                        </p>
                      </>
                    )}
                  </div>
                )}
              </>
            )}

            <div className="mt-6">
              <label className="block mb-2 font-bold text-foreground">
                {t('tournament.create.leagueScoring')}
              </label>
              <select
                name="league_scoring_system"
                value={formData.league_scoring_system || ''}
                onChange={handleChange}
                required
                className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="">{t('common.selectPlaceholder')}</option>
                <option value="points">{t('common.scoring.points')}</option>
                <option value="difference">{t('common.scoring.difference')}</option>
              </select>
              {formData.league_scoring_system === 'points' && (
                <p className="mt-2 text-sm text-muted-foreground italic">
                  {t('common.scoring.pointsDistribution')}
                </p>
              )}
            </div>

            {formData.mode === 'round_robin' && (
              <>
                <div className="mt-6">
                  <label className="block mb-2 font-bold text-foreground">
                    {t('tournament.create.leagueVariant')}
                  </label>
                  <select
                    name="league_variant"
                    value={formData.league_variant}
                    onChange={handleChange}
                    className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="classic">{t('common.leagueVariant.classic')}</option>
                    <option value="double">{t('common.leagueVariant.double')}</option>
                    <option value="multiple">{t('common.leagueVariant.multiple')}</option>
                  </select>
                  <p className="mt-2 text-sm text-muted-foreground italic">
                    {formData.league_variant === 'classic' && t('common.leagueVariant.classicDesc')}
                    {formData.league_variant === 'double' && t('common.leagueVariant.doubleDesc')}
                    {formData.league_variant === 'multiple' && t('common.leagueVariant.multipleDesc')}
                  </p>
                </div>

                {formData.league_variant === 'multiple' && (
                  <div className="mt-4">
                    <label className="block mb-2 font-bold text-foreground">
                      {t('tournament.create.roundsMultiplier')}
                    </label>
                    <input
                      type="number"
                      name="league_rounds_multiplier"
                      value={formData.league_rounds_multiplier}
                      onChange={(e) => setFormData(prev => ({ ...prev, league_rounds_multiplier: parseInt(e.target.value) || 1 }))}
                      min={2}
                      max={10}
                      required
                      className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    />
                    <p className="mt-2 text-sm text-muted-foreground italic">
                      {t('tournament.create.roundsMultiplierHint')}
                    </p>
                  </div>
                )}
              </>
            )}

            <div className="mt-4">
              <label className="block mb-2 font-bold text-foreground">
                {t('tournament.create.tieBreakingRules')}
              </label>
              
              <div className="mb-4 p-3 bg-card rounded-lg border border-border">
                <p className="m-0 mb-2 text-sm font-bold">{t('tournament.create.availableRules')}</p>
                <div className="flex flex-col gap-2">
                  {getAvailableTieBreakingRules().map(rule => {
                    const isDecisionMatch = rule === 'decision_match';
                    const hasDecisionMatch = formData.tie_breaking_rules.includes('decision_match');
                    const hasOtherRules = formData.tie_breaking_rules.some(r => r !== 'decision_match');
                    const isChecked = formData.tie_breaking_rules.includes(rule);
                    const isDisabled = (isDecisionMatch && hasOtherRules) || (!isDecisionMatch && hasDecisionMatch);
                    
                    return (
                      <label 
                        key={rule} 
                        className={cn(
                          "flex items-center gap-2",
                          isDisabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"
                        )}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          disabled={isDisabled}
                          onChange={(e) => {
                            if (e.target.checked) {
                              if (isDecisionMatch) {
                                setFormData(prev => ({
                                  ...prev,
                                  tie_breaking_rules: ['decision_match']
                                }));
                              } else {
                                setFormData(prev => ({
                                  ...prev,
                                  tie_breaking_rules: prev.tie_breaking_rules.filter(r => r !== 'decision_match').concat(rule)
                                }));
                              }
                            } else {
                              setFormData(prev => ({
                                ...prev,
                                tie_breaking_rules: prev.tie_breaking_rules.filter(r => r !== rule)
                              }));
                            }
                          }}
                        />
                        <span>{tieBreakingRuleLabels[rule]}</span>
                      </label>
                    );
                  })}
                </div>
                {formData.tie_breaking_rules.includes('decision_match') && (
                  <p className="mt-2 text-xs text-muted-foreground italic">
                    {t('tournament.create.decisionMatchHint')}
                  </p>
                )}
              </div>

              {formData.tie_breaking_rules.length > 0 && !formData.tie_breaking_rules.includes('decision_match') && (
                <div className="p-3 bg-muted rounded-lg border border-border">
                  <p className="m-0 mb-2 text-sm font-bold text-foreground">{t('tournament.create.ruleOrder')}</p>
                  <div className="flex flex-col gap-2">
                    {formData.tie_breaking_rules.map((rule, index) => (
                      <div key={`${rule}-${index}`} className="flex items-center gap-2 p-2 bg-card rounded-lg border border-border">
                        <span className="min-w-[2rem] font-bold text-muted-foreground">{index + 1}.</span>
                        <span className="flex-1">{tieBreakingRuleLabels[rule]}</span>
                        <div className="flex flex-col gap-1">
                          <button
                            type="button"
                            onClick={() => moveTieBreakingRule(index, 'up')}
                            disabled={index === 0}
                            className={cn(
                              "w-6 h-5 p-0 text-xs border-none rounded-sm",
                              index === 0 
                                ? "bg-muted-foreground/50 text-white cursor-not-allowed" 
                                : "bg-success text-white cursor-pointer hover:bg-success/90"
                            )}
                            title={t('tournament.create.moveUp')}
                          >
                            ▲
                          </button>
                          <button
                            type="button"
                            onClick={() => moveTieBreakingRule(index, 'down')}
                            disabled={index === formData.tie_breaking_rules.length - 1}
                            className={cn(
                              "w-6 h-5 p-0 text-xs border-none rounded-sm",
                              index === formData.tie_breaking_rules.length - 1 
                                ? "bg-muted-foreground/50 text-white cursor-not-allowed" 
                                : "bg-success text-white cursor-pointer hover:bg-success/90"
                            )}
                            title={t('tournament.create.moveDown')}
                          >
                            ▼
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            </div>
          </div>
        )}

        {(formData.mode === 'knockout' || formData.mode === 'combined') && (
          <div className="mb-4 ml-0 p-4 bg-card rounded-lg border border-border">
            <h3 className="mb-2 font-bold text-foreground">
              {formData.mode === 'knockout' ? t('tournament.create.koPhaseOnly') : t('tournament.create.koPhaseAfterGroup')}
            </h3>
            {formData.mode === 'combined' && (
              <p className="mb-4 text-sm text-muted-foreground italic">
                {t('tournament.create.koScoringHint')}
              </p>
            )}
            <div className="ml-4">
              {formData.mode === 'combined' && (
                <div className="mb-4">
                  <label className="block mb-2 font-bold text-foreground">
                    {t('tournament.create.koStartRound')}
                  </label>
                  <select
                    name="ko_start_round"
                    value={formData.ko_start_round || ''}
                    onChange={handleChange}
                    required
                    className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="">{t('common.selectPlaceholder')}</option>
                    <option value="round_of_32">{t('tournament.create.koStartRoundOptions.roundOf32')}</option>
                    <option value="round_of_16">{t('tournament.create.koStartRoundOptions.roundOf16')}</option>
                    <option value="quarterfinal">{t('tournament.create.koStartRoundOptions.quarterfinal')}</option>
                    <option value="semifinal">{t('tournament.create.koStartRoundOptions.semifinal')}</option>
                    <option value="final">{t('tournament.create.koStartRoundOptions.final')}</option>
                  </select>
                  
                  {loadingQualificationPlan && (
                    <p className="mt-2 text-sm text-muted-foreground">
                      {t('tournament.create.calculatingPlan')}
                    </p>
                  )}
                  {qualificationPlan && !loadingQualificationPlan && (
                    <div className="mt-4 p-4 bg-muted rounded-lg border border-border">
                      <div className="text-sm font-bold text-foreground mb-2">
                        {t('tournament.create.qualificationPlan')}
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        {t('tournament.create.qualificationTotal', { count: qualificationPlan.required_participants })}
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        {t('tournament.create.qualificationBasis', { count: qualificationPlan.basis_per_group })}
                      </div>
                      {qualificationPlan.fallback_rules.length > 0 && (
                        <div className="mt-2">
                          <div className="text-sm font-bold text-foreground mb-1">
                            {t('tournament.create.additionalQualifiers')}
                          </div>
                          {qualificationPlan.fallback_rules.map((rule, idx) => (
                            <div key={idx} className="text-sm text-muted-foreground">
                              • {t('tournament.create.bestPositioned', { count: rule.count, position: rule.position })}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
              {formData.mode === 'knockout' && (
                <div className="mb-4 p-3 bg-muted rounded-lg border border-border">
                  <p className="m-0 text-sm text-foreground">
                    {t('tournament.create.koAutoParticipants')}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block mb-2 font-bold text-foreground">
                    {t('tournament.create.koStructure')}
                  </label>
                  <select
                    name="ko_structure"
                    value={formData.ko_structure || ''}
                    onChange={handleChange}
                    required
                    className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <option value="">{t('common.selectPlaceholder')}</option>
                    {getAllowedKOStructures(formData.mode).map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex items-start pt-7">
                  {formData.ko_structure && (
                    <p className="m-0 text-sm text-muted-foreground italic">
                      {getAllowedKOStructures(formData.mode).find(o => o.value === formData.ko_structure)?.description}
                    </p>
                  )}
                </div>
              </div>

              {needsDrawMethod(formData.ko_structure, formData.ko_draw_method) && (
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block mb-2 font-bold text-foreground">
                      KO Paarungsart (P1-P7)
                    </label>
                    <select
                      value={formData.ko_pairing_mode}
                      onChange={(e) => {
                        const pairing = e.target.value as KOPairingVariant;
                        const derivedDrawMethod = deriveDrawMethodFromPairing(pairing);
                        setFormData((prev) => ({
                          ...prev,
                          ko_pairing_mode: pairing,
                          ko_draw_method: derivedDrawMethod as any,
                          ko_distribution:
                            derivedDrawMethod === 'manual'
                              ? 'predefined_slots'
                              : derivedDrawMethod === 'fixed_cross'
                                ? 'cross'
                                : prev.ko_distribution,
                          ko_block_same_group: pairing === 'P4' ? true : prev.ko_block_same_group,
                        }));
                      }}
                      className="w-full p-2 mb-3 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {PAIRING_VARIANTS.map((variant) => (
                        <option key={variant.id} value={variant.id}>
                          {variant.label}
                        </option>
                      ))}
                    </select>
                    <div className="rounded border border-border bg-card px-3 py-2 text-sm text-muted-foreground">
                      Abgeleitete Auslosung:{' '}
                      <span className="font-semibold text-foreground">
                        {getKoDrawMethodLabel(formData.ko_draw_method) || '—'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-start pt-7">
                    {formData.ko_draw_method && (
                      <p className="m-0 text-sm text-muted-foreground italic">
                        Die Auslosungslogik wird aus der Paarungsart abgeleitet.
                      </p>
                    )}
                  </div>
                </div>
              )}

              {needsKoDistribution(formData.ko_pairing_mode, formData.ko_draw_method) && (
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block mb-2 font-bold text-foreground">
                      {t('tournament.create.koDrawMode')}
                    </label>
                    <select
                      name="ko_distribution"
                      value={formData.ko_distribution || 'random_first_round'}
                      onChange={handleChange}
                      required
                      className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {koDrawModeOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-start pt-7">
                    <p className="m-0 text-sm text-muted-foreground italic">
                      {koDrawModeOptions.find(o => o.value === formData.ko_distribution)?.description}
                    </p>
                  </div>
                </div>
              )}

              {formData.has_group_phase && formData.ko_draw_method && (
                <div className="mb-4 p-3 bg-card rounded-lg border border-border">
                  <label className="block mb-2 font-bold text-foreground">
                    {t('tournament.create.drawRestrictions')}
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      name="ko_block_same_group"
                      checked={formData.ko_block_same_group}
                      onChange={handleChange}
                    />
                    <span>{t('tournament.create.noSameGroup')}</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      name="ko_block_same_position"
                      checked={formData.ko_block_same_position}
                      onChange={handleChange}
                    />
                    <span>{t('tournament.create.noSamePosition')}</span>
                  </label>
                </div>
              )}


              {needsGroupWinnerAdvantage(formData.ko_structure, formData.mode) && (
                <div className="mb-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      name="ko_group_winner_advantage"
                      checked={formData.ko_group_winner_advantage}
                      onChange={handleChange}
                    />
                    <span className="font-bold text-foreground">{t('tournament.create.groupWinnerAdvantage')}</span>
                  </label>
                </div>
              )}


              {(formData.ko_draw_method === 'pot_system' || formData.ko_draw_method === 'full_random') && (
                <div className="mb-4">
                  <label className="block mb-2 font-bold text-foreground">
                    {t('tournament.create.randomSeed')}
                  </label>
                  <input
                    type="number"
                    name="ko_random_seed"
                    value={formData.ko_random_seed || ''}
                    onChange={handleChange}
                    min={0}
                    placeholder={t('tournament.create.randomSeedPlaceholder')}
                    className="w-full p-2 text-base border border-border rounded-md bg-muted text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  />
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t('tournament.create.randomSeedHint')}
                  </p>
                </div>
              )}

              {formData.ko_draw_method === 'manual' && (
                <div className="mb-4 p-4 bg-warning/20 rounded-lg border border-warning">
                  <p className="m-0 mb-4 text-sm text-warning">
                    {formData.mode === 'combined'
                      ? t('tournament.create.manualPairingsCombined')
                      : t('tournament.edit.manualPairingsKO')}
                  </p>
                </div>
              )}
              <p className="mt-2 text-xs text-muted-foreground">
                {t('tournament.edit.drawChangeHint')}
              </p>
            </div>
          </div>
        )}

        <div className="mt-8 mb-4">
          <label className="block text-sm font-bold text-foreground mb-1.5">{t('common.visibility.label')}</label>
          <select
            value={formData.visibility}
            onChange={(e) => setFormData({ ...formData, visibility: e.target.value as any })}
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
          >
            <option value="public">{t('common.visibility.public')}</option>
            <option value="shared">{t('common.visibility.shared')}</option>
            <option value="private">{t('common.visibility.private')}</option>
          </select>
        </div>

        <div className="flex gap-4 mt-8">
          <Button
            type="submit"
            variant="success"
            disabled={loading || loadingTournament}
          >
            {loading ? t('tournament.edit.submitting') : t('tournament.edit.submit')}
          </Button>
          <Button
            type="button"
            variant="secondary"
            onClick={() => navigate(`/tournaments/${tournamentId}`)}
            disabled={loadingTournament}
          >
            {t('common.cancel')}
          </Button>
        </div>
      </form>
      </CardContent>
      </Card>
        )}
      </div>

      {/* Rechte Seite - Erklärungen */}
      <div className="flex-1 max-w-[400px]">
        <div className="sticky top-8">
          <Card className="mb-4 border-primary p-5">
            <CardHeader>
              <CardTitle className="mt-0 text-primary">{t('tournament.edit.title')}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4 leading-relaxed">
                {t('tournament.edit.infoDescription')}
              </p>
              <ul className="m-0 pl-7 pr-2 text-muted-foreground">
                <li className="mb-2">{t('tournament.edit.infoBasic')}</li>
                <li className="mb-2">{t('tournament.edit.infoConfig')}</li>
                <li className="mb-2">{t('tournament.edit.infoRegenerate')}</li>
                <li className="mb-2">{t('tournament.edit.infoParticipants')}</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="border-warning p-5">
            <CardHeader>
              <CardTitle className="mt-0 text-warning">{t('tournament.edit.currentMode', { mode: currentMode.title })}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-2 text-sm leading-relaxed">{currentMode.description}</p>
              <ul className="m-0 pl-7 pr-2 text-sm text-muted-foreground list-disc">
                {currentMode.features.map((feature, idx) => (
                  <li key={idx} className="mb-1.5">{feature}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <Card className="mt-4 border-warning">
            <CardHeader>
              <CardTitle className="mt-0 text-warning">{t('tournament.create.currentSettings')}</CardTitle>
            </CardHeader>
            <CardContent>
              {groupSettingsSummary.length > 0 ? (
                <>
                  <div className="font-bold text-foreground mb-2">{t('common.mode.groupPhase')}</div>
                  <ul className="m-0 pl-6 text-muted-foreground text-sm">
                    {groupSettingsSummary.map((item) => (
                      <li key={item} className="mb-1.5">{item}</li>
                    ))}
                  </ul>
                </>
              ) : (
                <div className="text-muted-foreground mb-3">{t('tournament.create.noGroupPhase')}</div>
              )}
              {koSettingsSummary.length > 0 ? (
                <>
                  <div className="font-bold text-foreground mt-4 mb-2">{t('common.mode.koPhase')}</div>
                  <ul className="m-0 pl-6 text-muted-foreground text-sm">
                    {koSettingsSummary.map((item) => (
                      <li key={item} className="mb-1.5">{item}</li>
                    ))}
                  </ul>
                </>
              ) : (
                <div className="text-muted-foreground mt-3">{t('tournament.create.noKoPhase')}</div>
              )}
              <div className="mt-4">
                <TournamentModeVisualization
                  mode={formData.mode}
                  modeVariant={formData.mode_variant}
                  hasGroupPhase={formData.has_group_phase}
                  hasKoPhase={formData.has_ko_phase}
                  groupsCount={formData.groups_count}
                  participantsPerGroup={formData.participants_per_group}
                  groupDistribution={formData.group_distribution}
                  koStartRound={formData.ko_start_round}
                  koStructure={formData.ko_structure}
                  koDrawMethod={formData.ko_draw_method}
                  koPairingMode={formData.ko_pairing_mode}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
