import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Button, Card, CardContent, Input } from '@/components/ui';
import { locationService } from '../services/locationService';
import { Location } from '../types';
import { ArrowLeft } from 'phosphor-react';

export default function EditLocation() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [location, setLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'shared' | 'private'>('public');

  useEffect(() => {
    if (!id) return;
    loadLocation();
  }, [id]);

  const loadLocation = async () => {
    setLoading(true);
    try {
      const data = await locationService.getById(Number(id));
      setLocation(data);
      setName(data.name);
      setVisibility(data.visibility || 'public');
    } catch (err) {
      console.warn('Spielort konnte nicht geladen werden.', err);
      setLocation(null);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location || !name.trim()) return;
    setError(null);
    setSaving(true);
    try {
      await locationService.update(location.id, { name: name.trim(), visibility });
      navigate(`/locations/${location.id}`);
    } catch (err: any) {
      setError(err?.response?.data?.detail || t('locations.edit.error'));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-foreground">{t('common.loading')}</div>;
  }
  if (!location) {
    return (
      <div className="p-8 text-foreground">{t('locations.edit.notFound')}</div>
    );
  }

  return (
    <div className="p-8 bg-background min-h-screen text-foreground">
      <div className="mb-6">
        <Button variant="secondary" onClick={() => navigate(`/locations/${location.id}`)}>
          <ArrowLeft size={18} className="mr-2 align-middle" />
          {t('common.back')}
        </Button>
      </div>
      <Card className="max-w-[400px]">
        <CardContent className="p-6">
          <h2 className="mt-0 text-foreground">{t('locations.edit.title')}</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block mb-2 text-muted-foreground">{t('locations.create.nameLabel')}</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t('locations.create.namePlaceholder')}
                required
                className="w-full"
              />
            </div>
            <div className="mb-4">
              <label className="block mb-2 text-muted-foreground">{t('common.visibility.label')}</label>
              <select
                value={visibility}
                onChange={(e) => setVisibility(e.target.value as 'public' | 'shared' | 'private')}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
              >
                <option value="public">{t('common.visibility.public')}</option>
                <option value="shared">{t('common.visibility.shared')}</option>
                <option value="private">{t('common.visibility.private')}</option>
              </select>
            </div>
            {error && <p className="text-destructive mb-4">{error}</p>}
            <Button type="submit" disabled={saving}>
              {saving ? t('locations.edit.submitting') : t('common.save')}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
