import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, Input, Button } from '../components/ui';
import { Envelope, Key, UserPlus, CheckCircle } from 'phosphor-react';
import { registrationService } from '../services/registrationService';
import Footer from '../components/Footer';
import LanguageSwitcher from '../components/LanguageSwitcher';

type Step = 'form' | 'otp' | 'done';

export default function Register() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [step, setStep] = useState<Step>('form');
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);

    try {
      const res = await registrationService.register({ email, first_name: firstName, last_name: lastName });

      if (res.dev_otp_code) {
        setInfo(`DEV-OTP: ${res.dev_otp_code}`);
        try {
          await registrationService.verifyOTP(email, res.dev_otp_code);
          setStep('done');
          return;
        } catch (err: any) {
          setError(err.response?.data?.detail || t('register.verificationFailed'));
          return;
        }
      } else {
        setInfo(t('register.codeSentInfo'));
      }
      setStep('otp');
    } catch (err: any) {
      setError(err.response?.data?.detail || t('register.registrationFailed'));
    } finally {
      setLoading(false);
    }
  };

  const handleOTPSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await registrationService.verifyOTP(email, otpCode);
      setStep('done');
    } catch (err: any) {
      setError(err.response?.data?.detail || t('register.invalidCode'));
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setStep('form');
    setOtpCode('');
    setError('');
    setInfo('');
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <div className="absolute top-4 right-4 z-10">
        <LanguageSwitcher />
      </div>
      <div className="flex justify-center items-center flex-1">
        <Card className="w-[440px]">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">{t('login.appName')}</CardTitle>
            <CardDescription>{t('login.appDescription')}</CardDescription>
          </CardHeader>

          <CardContent>
            {step === 'form' && (
              <>
                <h2 className="text-xl font-semibold text-center text-foreground mb-6">{t('register.title')}</h2>
                <form onSubmit={handleRegisterSubmit} className="space-y-4">
                  <Input
                    label={t('register.firstName')}
                    type="text"
                    value={firstName}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFirstName(e.target.value)}
                    required
                  />
                  <Input
                    label={t('register.lastName')}
                    type="text"
                    value={lastName}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLastName(e.target.value)}
                    required
                  />
                  <Input
                    label={t('register.email')}
                    type="email"
                    value={email}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                    required
                  />

                  {info && (
                    <div className="p-3 rounded-lg border border-primary bg-primary/10 text-primary text-sm">
                      {info}
                    </div>
                  )}
                  {error && (
                    <div className="p-3 rounded-lg border border-destructive bg-destructive/10 text-destructive text-sm">
                      {error}
                    </div>
                  )}

                  <Button type="submit" disabled={loading} className="w-full gap-2">
                    {loading ? t('register.sending') : (
                      <>
                        <Envelope size={18} /> {t('register.sendCode')}
                      </>
                    )}
                  </Button>

                  <div className="text-center mt-4">
                    <button
                      type="button"
                      onClick={() => navigate('/login')}
                      className="text-sm text-primary hover:underline bg-transparent border-none cursor-pointer"
                    >
                      {t('register.alreadyAccount')}
                    </button>
                  </div>
                </form>
              </>
            )}

            {step === 'otp' && (
              <>
                <h2 className="text-xl font-semibold text-center text-foreground mb-6">{t('register.codeTitle')}</h2>
                <form onSubmit={handleOTPSubmit} className="space-y-4">
                  <p className="text-sm text-muted-foreground text-center" dangerouslySetInnerHTML={{ __html: t('register.codeSent', { email }) }} />
                  <Input
                    label={t('register.confirmationCode')}
                    type="text"
                    value={otpCode}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOtpCode(e.target.value)}
                    required
                  />

                  {error && (
                    <div className="p-3 rounded-lg border border-destructive bg-destructive/10 text-destructive text-sm">
                      {error}
                    </div>
                  )}

                  <div className="flex gap-3">
                    <Button type="button" variant="secondary" onClick={handleBack} className="flex-1">
                      {t('common.back')}
                    </Button>
                    <Button type="submit" disabled={loading} className="flex-1 gap-2">
                      {loading ? t('register.verifying') : (
                        <>
                          <Key size={18} /> {t('register.confirm')}
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </>
            )}

            {step === 'done' && (
              <div className="text-center space-y-4 py-4">
                <CheckCircle size={48} weight="fill" className="text-green-500 mx-auto" />
                <h2 className="text-xl font-semibold text-foreground">{t('register.emailVerified')}</h2>
                <p className="text-muted-foreground">
                  {t('register.submittedMessage')}
                </p>
                <p className="text-sm text-muted-foreground">
                  {t('register.notificationMessage')}
                </p>
                <Button variant="secondary" onClick={() => navigate('/login')} className="mt-4 gap-2">
                  <UserPlus size={18} /> {t('register.goToLogin')}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}
