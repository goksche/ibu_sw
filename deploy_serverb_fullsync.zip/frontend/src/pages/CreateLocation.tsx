import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Button, Card, CardContent, Input } from '@/components/ui';
import { locationService } from '../services/locationService';
import { ArrowLeft } from 'phosphor-react';

export default function CreateLocation() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'shared' | 'private'>('public');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError(t('locations.create.nameRequired'));
      return;
    }
    setLoading(true);
    try {
      const loc = await locationService.create({ name: name.trim(), visibility });
      navigate(`/locations/${loc.id}`);
    } catch (err: any) {
      setError(err?.response?.data?.detail || t('locations.create.error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 bg-background min-h-screen text-foreground">
      <div className="mb-6">
        <Button variant="secondary" onClick={() => navigate('/locations')}>
          <ArrowLeft size={18} className="mr-2 align-middle" />
          {t('common.back')}
        </Button>
      </div>
      <Card className="max-w-[400px]">
        <CardContent className="p-6">
          <h2 className="mt-0 text-foreground">{t('locations.create.title')}</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block mb-2 text-muted-foreground">{t('locations.create.nameLabel')}</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t('locations.create.namePlaceholder')}
                required
                className="w-full"
              />
            </div>
            <div className="mb-4">
              <label className="block mb-2 text-muted-foreground">{t('common.visibility.label')}</label>
              <select
                value={visibility}
                onChange={(e) => setVisibility(e.target.value as 'public' | 'shared' | 'private')}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground"
              >
                <option value="public">{t('common.visibility.public')}</option>
                <option value="shared">{t('common.visibility.shared')}</option>
                <option value="private">{t('common.visibility.private')}</option>
              </select>
            </div>
            {error && <p className="text-destructive mb-4">{error}</p>}
            <Button type="submit" disabled={loading}>
              {loading ? t('locations.create.submitting') : t('common.create')}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
