# Locations API - CRUD for Locations and Spielfelder
# v1.4.0

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.core.dependencies import require_user_or_admin, require_viewer_or_above
from app.services.visibility import get_accessible_location, get_visible_locations_query
from app.models.location import Location, Spielfeld
from app.models.user import UserRole
from app.schemas.location import (
    LocationCreate,
    LocationUpdate,
    LocationResponse,
    LocationListResponse,
    SpielfeldCreate,
    SpielfeldCreateForLocation,
    SpielfeldUpdate,
    SpielfeldResponse,
)

router = APIRouter(prefix="/locations", tags=["Locations"])


def _location_to_response(loc: Location) -> LocationResponse:
    return LocationResponse(
        id=loc.id,
        name=loc.name,
        visibility=getattr(loc, "visibility", "public"),
        spielfelder=[SpielfeldResponse.model_validate(s) for s in loc.spielfelder],
        created_at=loc.created_at,
        updated_at=loc.updated_at,
    )


def _is_admin_or_power_admin(current_user) -> bool:
    return current_user.role in (UserRole.ADMIN, UserRole.POWER_ADMIN)


def _ensure_location_editable(db: Session, location_id: int, current_user) -> Location:
    location = db.query(Location).filter(Location.id == location_id).first()
    if not location:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Location not found")
    if _is_admin_or_power_admin(current_user):
        return location
    if getattr(location, "creator_id", None) == current_user.id:
        return location
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Keine Berechtigung für diesen Spielort")


@router.get("", response_model=List[LocationListResponse])
def get_locations(
    current_user=Depends(require_viewer_or_above),
    db: Session = Depends(get_db),
):
    locations = get_visible_locations_query(db, current_user).order_by(Location.name).all()
    return [_location_to_response(loc) for loc in locations]


@router.get("/{location_id}", response_model=LocationResponse)
def get_location(
    location_id: int,
    current_user=Depends(require_viewer_or_above),
    db: Session = Depends(get_db),
):
    loc = get_accessible_location(db, location_id, current_user)
    return _location_to_response(loc)


@router.post("", response_model=LocationResponse, status_code=status.HTTP_201_CREATED)
def create_location(
    payload: LocationCreate,
    current_user=Depends(require_user_or_admin),
    db: Session = Depends(get_db),
):
    loc = Location(name=payload.name, visibility=payload.visibility, creator_id=current_user.id)
    db.add(loc)
    db.commit()
    db.refresh(loc)
    return _location_to_response(loc)


@router.put("/{location_id}", response_model=LocationResponse)
def update_location(
    location_id: int,
    payload: LocationUpdate,
    current_user=Depends(require_user_or_admin),
    db: Session = Depends(get_db),
):
    loc = _ensure_location_editable(db, location_id, current_user)
    if payload.name is not None:
        loc.name = payload.name
    if payload.visibility is not None:
        loc.visibility = payload.visibility
    db.commit()
    db.refresh(loc)
    return _location_to_response(loc)


@router.delete("/{location_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_location(
    location_id: int,
    current_user=Depends(require_user_or_admin),
    db: Session = Depends(get_db),
):
    loc = _ensure_location_editable(db, location_id, current_user)
    db.delete(loc)
    db.commit()
    return None


# Spielfelder unter einer Location
@router.get("/{location_id}/spielfelder", response_model=List[SpielfeldResponse])
def get_spielfelder(
    location_id: int,
    current_user=Depends(require_viewer_or_above),
    db: Session = Depends(get_db),
):
    loc = get_accessible_location(db, location_id, current_user)
    return [SpielfeldResponse.model_validate(s) for s in loc.spielfelder]


@router.post("/{location_id}/spielfelder", response_model=SpielfeldResponse, status_code=status.HTTP_201_CREATED)
def create_spielfeld(
    location_id: int,
    payload: SpielfeldCreateForLocation,
    current_user=Depends(require_user_or_admin),
    db: Session = Depends(get_db),
):
    _ensure_location_editable(db, location_id, current_user)
    s = Spielfeld(location_id=location_id, name=payload.name, sort_order=payload.sort_order)
    db.add(s)
    db.commit()
    db.refresh(s)
    return SpielfeldResponse.model_validate(s)


@router.put("/spielfelder/{spielfeld_id}", response_model=SpielfeldResponse)
def update_spielfeld(
    spielfeld_id: int,
    payload: SpielfeldUpdate,
    current_user=Depends(require_user_or_admin),
    db: Session = Depends(get_db),
):
    s = db.query(Spielfeld).filter(Spielfeld.id == spielfeld_id).first()
    if not s:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Spielfeld not found")
    _ensure_location_editable(db, s.location_id, current_user)
    if payload.name is not None:
        s.name = payload.name
    if payload.sort_order is not None:
        s.sort_order = payload.sort_order
    db.commit()
    db.refresh(s)
    return SpielfeldResponse.model_validate(s)


@router.delete("/spielfelder/{spielfeld_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_spielfeld(
    spielfeld_id: int,
    current_user=Depends(require_user_or_admin),
    db: Session = Depends(get_db),
):
    s = db.query(Spielfeld).filter(Spielfeld.id == spielfeld_id).first()
    if not s:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Spielfeld not found")
    _ensure_location_editable(db, s.location_id, current_user)
    db.delete(s)
    db.commit()
    return None
