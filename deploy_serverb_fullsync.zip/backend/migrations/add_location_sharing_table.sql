-- V1.7+: Sharing table for locations
CREATE TABLE IF NOT EXISTS location_shares (
    id SERIAL PRIMARY KEY,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    shared_with_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    shared_with_email VARCHAR(200),
    permission VARCHAR(10) NOT NULL DEFAULT 'view',
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE(location_id, shared_with_user_id),
    UNIQUE(location_id, shared_with_email)
);
