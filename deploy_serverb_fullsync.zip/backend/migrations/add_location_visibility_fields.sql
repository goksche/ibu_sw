-- V1.7+: Visibility + creator for locations
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'locations' AND column_name = 'visibility'
    ) THEN
        ALTER TABLE locations ADD COLUMN visibility VARCHAR(10) NOT NULL DEFAULT 'public';
    END IF;
END
$$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'locations' AND column_name = 'creator_id'
    ) THEN
        ALTER TABLE locations ADD COLUMN creator_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
    END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_locations_visibility ON locations(visibility);
