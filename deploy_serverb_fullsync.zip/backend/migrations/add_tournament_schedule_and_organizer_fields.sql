-- V1.7+: Organizer + schedule window settings for tournaments
DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'tournaments'
          AND column_name = 'organizer'
    ) THEN
        ALTER TABLE tournaments
            ADD COLUMN organizer VARCHAR(200) NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'tournaments'
          AND column_name = 'play_time_start'
    ) THEN
        ALTER TABLE tournaments
            ADD COLUMN play_time_start TIME NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'tournaments'
          AND column_name = 'play_time_end'
    ) THEN
        ALTER TABLE tournaments
            ADD COLUMN play_time_end TIME NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'tournaments'
          AND column_name = 'match_duration_minutes'
    ) THEN
        ALTER TABLE tournaments
            ADD COLUMN match_duration_minutes INTEGER NOT NULL DEFAULT 0;
    END IF;
END $$;
