-- V1.7+: Tournament-local temporary spielfelder count (without global location entity)
DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'tournaments'
          AND column_name = 'temporary_spielfelder_count'
    ) THEN
        ALTER TABLE tournaments
            ADD COLUMN temporary_spielfelder_count INTEGER NOT NULL DEFAULT 0;
    END IF;
END $$;
